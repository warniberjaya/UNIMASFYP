package com.example.covid19_info;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
