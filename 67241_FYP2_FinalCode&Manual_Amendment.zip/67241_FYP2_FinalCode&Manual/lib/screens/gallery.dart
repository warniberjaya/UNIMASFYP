
/*
import 'package:covid19_info/admin/adminscreens/addpost.dart';
import 'package:flutter/material.dart';

class InfoImage extends StatelessWidget {
  final addPost _addPost;

  InfoImage(this._addPost)

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Card(
        child: Padding(
            padding: const EdgeInsets.all(12.0)),
            child: Column(
              children: [
                Row(
                  children: [
                    Padding(padding: const EdgeInsets.only(bottom: 10.0)
                    child: Text("${_addPost.discription}"),
                    )
                  ],
                ),
              Row(
              children: [
                Text(_addPost.image!.capitalize(),
    style: Theme.of(),)
    ],
    )
              ],
            )
      ),
    );
  }
}
*/

