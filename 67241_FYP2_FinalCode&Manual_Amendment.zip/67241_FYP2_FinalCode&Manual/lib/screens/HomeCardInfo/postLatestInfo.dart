import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:faker/faker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
//import 'package:covid19_info/admin/services/storage_service.dart;


import '../../admin/adminscreens/imageData.dart';




class displayPost extends StatefulWidget {
  const displayPost({Key? key}) : super(key: key);

  @override
  _displayPostState createState() => _displayPostState();
}

class _displayPostState extends State<displayPost> {


  List<imageData> dataList = [];

  String imageName = "";
 // XFile? imagePath;
 // final ImagePicker _picker = ImagePicker();
  var descriptionController = new TextEditingController();

 final FirebaseFirestore firestoreRef = FirebaseFirestore.instance;
  final FirebaseStorage storageRef = FirebaseStorage.instance;
  String collectionName = "Image";


  //bool _isLoading = false;


  @override
  Widget build(BuildContext context) {
    // final Storage storage = Storage();
    return Scaffold(
      appBar: AppBar(
        // automaticallyImplyLeading: false,
        title: Text('Upload Latest Cases'),
        centerTitle: true,
      ),
      body:SafeArea(
        child: FutureBuilder<QuerySnapshot>(
          future: firestoreRef.collection(collectionName).get(),
          builder: (context, snapshot){
            print(snapshot.hasData);

            if(snapshot.connectionState== ConnectionState.waiting){
              return Center(
                child: CircularProgressIndicator(),
              );
            }else if(snapshot.hasData && snapshot.data!.docs.length>0){
              List<DocumentSnapshot> arrData = snapshot.data!.docs;
              print(arrData.length);
              print(arrData[0]['description']);

              //SHOW DATA HERE
              return ListView.builder(
                  itemCount: arrData.length,
                  itemBuilder: (context, index){
                    return Card(
                      child: Column(

                        children: [
                          Image.network(arrData[index]['image'],
                            height: 400,width: 300, fit: BoxFit.fill,
                            loadingBuilder: (context, child, loadingProgress){
                            if(loadingProgress==null){
                              return child;
                            }else {
                              return Center(child: CircularProgressIndicator(value:loadingProgress.expectedTotalBytes!=
                                  null? loadingProgress.cumulativeBytesLoaded/loadingProgress.expectedTotalBytes!: null),
                              );
                            }

                            },),
                          SizedBox(
                            width: 40,
                          ),
                          Text(arrData[index]['description']),
                        ],

                      ),

                    );
                  }
              );
            }else{
              return Center(
                child: Text("No Data Found"),
              );
            }

          }
          
        ),
      )
            
           
          );
    
  }


}
