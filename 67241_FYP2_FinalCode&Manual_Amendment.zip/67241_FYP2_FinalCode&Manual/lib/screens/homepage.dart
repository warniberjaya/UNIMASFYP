
import 'package:covid19_info/mapping/markerWidget.dart';
import 'package:covid19_info/screens/chatbot3.dart';
import 'package:covid19_info/screens/swkcuriosities.dart';
import 'package:covid19_info/screens/swkdivision.dart';
import 'package:covid19_info/user/signup/signup.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';


import '../mapping/mapShow.dart';
import '../mapping/showMark10.dart';
import '../mapping/showMarker.dart';
import '../route/routing_page.dart';
import '../user/login/login.dart';
import '../utils/bottom_menu.dart';
import '../screens/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../mapping/sarawakmap.dart';
import 'HomeCardInfo/postLatestInfo.dart';
import 'InfoScreen.dart';
import 'package:covid19_info/mapping/contohMap.dart';


class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int selectedIndex = 0;

  List screens = [
    MainPage(),
    InfoScreen(),
   // MarkerPage(),
    CovidMap(),
    ChatBot3(),

  ];

  void onClicked(int index) {
    setState(() {
      selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(

          child: screens.elementAt(selectedIndex),
        ),
        bottomNavigationBar: BottomMenu(
          selectedIndex: selectedIndex,
          onClicked: onClicked,

        )
    );
  }
}

  class MainPage extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
    home:
     Scaffold(
        appBar: AppBar(
          leading: Icon(
            Icons.menu,
            color: Colors.black87,
          ),

          actions: <Widget>[
            Text("\nLog Out", style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.w400,
                color: Colors.black87),
            ),IconButton(

              onPressed: () => FirebaseAuth.instance.signOut(

              ),
              icon: Icon(Icons.logout_rounded),
                color: Colors.black,
              ),
          ],
          elevation: 0.0,
          backgroundColor: Colors.white,
        ),
        body:
        Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 15.0),
          child: Column(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Sarawak Covid-19 Information',
                      style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.w400,
                          color: Colors.black87),
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    Text(
                      'Sarawak Infection Place',
                      style: TextStyle(
                          fontSize: 20.0,
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 2.0),
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    Stack(
                      children: <Widget>[
                        Container(
                          height: 168,
                          decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              color: Color(0xFF003D64),
                              borderRadius: BorderRadius.circular(20.0),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                    color: Colors.black45,
                                    offset: Offset(0.0, 10.0),
                                    blurRadius: 10.0)
                              ]),
                        ),
                        Container(
                          alignment: FractionalOffset.centerRight,
                          child: Image(
                            image: AssetImage(
                              'assets/image/Picture2.png',
                            ),
                            height: 168,
                            width: 190,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10.0, top: 30.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Sarawak COVID-19',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 24.0,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(
                                height: 5.0,
                              ),
                              Text(
                                'Infographic',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(
                                height: 5.0,
                              ),
                              Container(
                                height: 40.0,
                                width: 150.0,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(30),
                                  color: Color(0xFF00578D),
                                ),
                                child: GestureDetector(
                                  onTap: () {
                                    RoutingPage.goTonext(
                                      context: context,
                                      navigateTo: displayPost(),
                                    );
                                  },
                                  child: RichText(
                                    text: TextSpan(
                                      text: '\n\tLearn More',
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                      children: [
                                        WidgetSpan(
                                          child: Icon(
                                            Icons.arrow_forward,
                                            color: Colors.white,
                                          ),
                                          alignment: PlaceholderAlignment.middle,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 25.0,
                    ),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          cards(

                            colour: Color(0xFFE44E4F),
                            img: 'assets/image/wash_hands.png',
                            height: 80,
                            width: 170,
                            title: 'Prevention',
                            subtitle: 'Wash Hand',
                          ),
                          cards(

                            colour: Color(0xFF6674F1),
                            img: 'assets/image/wear_mask.png', // <--image
                            height: 80,
                            width: 160,
                            title: ' Prevention ',
                            subtitle: 'Wear Mask',
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          cards(

                            colour: Color(0xFF1A95B6),
                            img: 'assets/image/Picture3.png',
                            height: 100,
                            width: 150,
                            title: 'Symptoms',
                            subtitle: 'Check Doctor',
                          ),
                          cards(

                            colour: Color(0xFFE67E49),
                            img: 'assets/image/globe.png',
                            height: 100,
                            width: 160,
                            title: 'Global',
                            subtitle: 'Pandemic',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}