import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ScreenDivision extends StatefulWidget {
  const ScreenDivision({Key? key}) : super(key: key);

  @override
  _ScreenDivisionState createState() => _ScreenDivisionState();
}

class _ScreenDivisionState extends State<ScreenDivision> {

  final databaseRef = FirebaseDatabase.instance.ref().child("Cases");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('Infection Location'),
        centerTitle: true,
      ),
      body:
      SafeArea(

        child: FirebaseAnimatedList(query: databaseRef,itemBuilder:(BuildContext context,DataSnapshot snapshot,
            Animation<double>animation, int index){
         // var x = snapshot.child('address').value.toString();
          return ListTile(
            title: Text("City: "+ snapshot.child('city').value.toString()+ "\t\tCovid case:\t\t"+ snapshot.child('case').value.toString()),
            subtitle: Text("Division : "+ snapshot.child('division').value.toString() + "\t\tPostal Code:\t\t\t"+ snapshot.child('postalCode').value.toString()),

            
            trailing: IconButton(
              onPressed: (){
                var keyFinder = snapshot.key;
                print(keyFinder);
              }, icon: Icon(Icons.home),
              
            ),
          );
        }),
      ),

    );
  }
}
