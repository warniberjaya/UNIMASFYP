import 'package:covid19_info/screens/swkdivision.dart';
import 'package:covid19_info/screens/userviepdf.dart';
import 'package:flutter/material.dart';
import 'package:covid19_info/mapping/showList.dart';

class InfoScreen extends StatefulWidget {
  const InfoScreen({Key? key}) : super(key: key);

  @override
  _InfoScreenState createState() => _InfoScreenState();
}

class _InfoScreenState extends State<InfoScreen> {
  @override
            Widget build(BuildContext context) {
              return Scaffold(
                  appBar: AppBar(
                  automaticallyImplyLeading: false,
                  title: Text("View Information"),),
              body:
              Column(

                  children: [
                  Expanded(
                  child: Center(
                  child: SingleChildScrollView(
                  child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
              children: [

                  Text("Sarawak Information"),
                  SizedBox(height: 50,),


                  SizedBox(height: 30),
                  ElevatedButton(
                  onPressed: () async {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ListInfection()));
                          },
                          child: Container(
                          height: 50,
                          width: 100,
                          color: Colors.blue,
                          child: Center(
                          child: Text(
                          "Infection List",
                               ),
                        ),
                          ),
                       ),
                SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () async {
                    Navigator.push(context, MaterialPageRoute(builder: (context) =>ScreenDivision()));
                  },
                  child: Container(
                    height: 50,
                    width: 100,
                    color: Colors.blue,
                    child: Center(
                      child: Text(
                        "Infection Cases",
                      ),
                    ),
                  ),
                ),
                  SizedBox(height: 30),
                    ElevatedButton(
                    onPressed: () async {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => viewPDF()));
                    },
                    child: Container(
                    height: 50,
                    width: 100,
                    color: Colors.blue,
                    child: Center(
                    child: Text(
                    "Document Information",
                    ),
                    ),
                    ),
                    ),
                    SizedBox(height: 30)
            ]
              )

              )
    )
    )
    ]
    )
    );

  }
}

