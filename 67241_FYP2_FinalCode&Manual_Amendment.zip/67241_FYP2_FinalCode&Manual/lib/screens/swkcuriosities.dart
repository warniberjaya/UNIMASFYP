import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ScreenCuriosities extends StatefulWidget {
  const ScreenCuriosities({Key? key}) : super(key: key);

  @override
  _ScreenCuriositiesState createState() => _ScreenCuriositiesState();
}

class _ScreenCuriositiesState extends State<ScreenCuriosities> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
