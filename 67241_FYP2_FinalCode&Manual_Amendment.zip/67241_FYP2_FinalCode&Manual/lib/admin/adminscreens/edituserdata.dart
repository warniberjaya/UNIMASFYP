import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class EditUser extends StatefulWidget {
  final String userUid;

  EditUser(  {required Key? key, required this.userUid}) : super(key: key);
  @override
  _EditUserState createState() => _EditUserState();
}

class _EditUserState extends State<EditUser> {
  TextEditingController fullNameController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit User'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextFormField(
            controller: fullNameController,
            decoration: InputDecoration(
                hintText: "Role..."
            ),
          ),
          TextFormField(
            controller: passwordController,
            decoration: InputDecoration(
                hintText: "Password..."
            ),
          ),
          GestureDetector(
            onTap: () async {
              String newFullName = fullNameController.text.trim();
              String newPassword = passwordController.text.trim();

              FirebaseFirestore.instance.collection('users').doc(widget.userUid).update({
                'fullName': newFullName,
                'password': newPassword,
              });
            },
            child: Container(
              height: 50,
              width: 100,
              color: Colors.blue,
              child: Center(
                child: Text(
                  "UPDATE DATA",
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}