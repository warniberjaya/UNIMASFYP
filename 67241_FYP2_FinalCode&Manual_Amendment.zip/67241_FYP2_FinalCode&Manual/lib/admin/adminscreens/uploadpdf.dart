import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class uploadPDF extends StatefulWidget {
  const uploadPDF({Key? key}) : super(key: key);

  @override
  _uploadPDFState createState() => _uploadPDFState();
}

class _uploadPDFState extends State<uploadPDF> {


  String url="";
  int? number;

  uploadDataToFirebase()async{
    //generate random number
    number = Random().nextInt(10);



    //pick pdf file
  FilePickerResult? result = await FilePicker.platform.pickFiles();
  File pick = File(result!.files.single.path.toString());
  var file = pick.readAsBytesSync();
  String name = DateTime.now().millisecondsSinceEpoch.toString();


  //uploading file to firebase
    var pdfFile = FirebaseStorage.instance.ref().child(name).child("/.pdf");
    UploadTask task = pdfFile.putData(file);
    TaskSnapshot snapshot = await task;
    url = await snapshot.ref.getDownloadURL();

    //upload url cloud firebase
    await FirebaseFirestore.instance.collection("file").doc().set({

      'fileUrl': url,
      'num':"covid "+number.toString(),

    });



  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("PDF"),
      ),
      body: StreamBuilder(
          stream: FirebaseFirestore.instance.collection("file").snapshots(),
          builder: (context,AsyncSnapshot<QuerySnapshot> snapshot){
          if(snapshot.hasData){
            return ListView.builder(
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (context,i){
              QueryDocumentSnapshot x = snapshot.data!.docs[i];
              return InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context)=> View(url: x['fileUrl'],)));
                },
                child: Card(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(children:[
                  Text("INFO LATEST",
                  style: TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                      SizedBox(height: 10,),
                      Row(
                      children:
                      [
                        Expanded(flex: 1, child: Text(x["num"])),
                    ]
                  ),
                      SizedBox(height: 10,),
                    ],
                  ),
                ),
              ));

            });

          }return Center(child: CircularProgressIndicator(),);
        }
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: uploadDataToFirebase, child: Icon(Icons.add) ,),
    );
  }
}

class View extends StatelessWidget {
  PdfViewerController? _pdfViewerController;

      final url;
      View({this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar (
        title: Text("PDF View"),
      ),
      body: SfPdfViewer.network(
        url,
        controller: _pdfViewerController,
      ),
    );
  }
}
