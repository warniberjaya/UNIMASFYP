

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class infecLocation extends StatefulWidget {
  const infecLocation({Key? key}) : super(key: key);

  @override
  _infecLocationState createState() => _infecLocationState();
}

class _infecLocationState extends State<infecLocation> {

  final databaseRef = FirebaseDatabase.instance.ref().child("Location");


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title: Text('Infection Cases'),
        centerTitle: true,
      ),
      body:
      SafeArea(

        child: FirebaseAnimatedList(
            query: databaseRef,
            itemBuilder:(BuildContext context,snapshot,
                Animation<double>animation, int index){
         //     QuerySnapshot x = snapshot.data!.docs[index];
                  return ListTile(
                    title: Text(snapshot.child('address').value.toString()),
                      subtitle: Text(snapshot.child('city').value.toString() + "\t"+ snapshot.child('postalCode').value.toString()),

            trailing: Wrap(
              children:<Widget>[
                IconButton(
                onPressed: (){
                  var key = snapshot.key;
                 print("Delete Address: "+ key.toString());
                  _deleteRecord(key);

                }, icon: Icon(Icons.delete),

              ),
                    // edit button
                    IconButton(
                      onPressed: (){

                      //  var keyFinder = snapshot.key;
                     //  _showUpdateDialog(snapshot.value[index]['address'], snapshot.value['city'],snapshot.value['division'],snapshot.value['postalCode'],context);

                      }, icon: Icon(Icons.edit),

                    ),
              ]
          ));
        }),
      ),

    );
  }
    //user-> key
  _deleteRecord(var key) async{
    await databaseRef.child(key).remove();
  }

  //update data
  Future<void> _showUpdateDialog(String address,String city,String division, String postalCode, BuildContext context){
    var addressController = new TextEditingController(text: address);
    var cityController = new TextEditingController(text: city);
    var postalCodeController = new TextEditingController(text: postalCode);
    var divisionController = new TextEditingController(text: division);


    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context){

          return AlertDialog(
            title: Text("Update Value" ),
            content: SingleChildScrollView(
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [

                    TextFormField(
                      controller: addressController ,
                      decoration: InputDecoration(
                        hintText: "Full Name",
                      ),
                    ),
                    SizedBox(height: 10,),
                    TextFormField(
                      controller: cityController,
                      decoration: InputDecoration(
                        hintText: "Email",
                      ),
                    ),
                      SizedBox(height: 10,),
                 TextFormField(
                 controller: postalCodeController,
                 decoration: InputDecoration(
                 hintText: "Password",
              ),
              ),
                    SizedBox(height: 10,),
                    TextFormField(
                      controller: divisionController,
                      decoration: InputDecoration(
                        hintText: "Role",
                      ),
                    ),
                  ]
              ),
            ),
            actions:[
              TextButton( onPressed: () {
                Navigator.of(context).pop();
              },
                  child: Text("Cancel")),
              TextButton(
                  onPressed:(){
                    if (addressController.text.isNotEmpty &&
                        cityController.text.isNotEmpty &&
                        postalCodeController.text.isNotEmpty &&
                        divisionController.text.isNotEmpty
                    ){
                      //call function
                  /*    updateData(addressController.text,
                          cityController.text, postalCodeController.text, divisionController.text,);
                        Navigator.of(context).pop();*/
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text("Please Enter All Fields Value")));

                    }
                  },
                  child: Text("Update")

              )
            ],
          );
        }
    );
  }

  void updateData(String address,String city,String division, String postalCode, var keyFinder ){
    Map<String, String> x ={"address": address, "city": city, "division": division, "postalCode": postalCode};
    databaseRef.child(keyFinder).update(x);
  }


}
