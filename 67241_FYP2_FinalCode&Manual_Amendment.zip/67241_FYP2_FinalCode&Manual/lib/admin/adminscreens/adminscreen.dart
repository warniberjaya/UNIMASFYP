import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:covid19_info/admin/adminscreens/infecLocation.dart';
import 'package:covid19_info/admin/adminscreens/updateUser3.dart';
import 'package:covid19_info/admin/adminscreens/uploadpdf.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../realtime_db/realtimedblocation.dart';
import 'ListExpose.dart';
import 'addpost.dart';
import 'createuserscreen.dart';
import 'edituserdata.dart';
import 'mapping.dart';
import 'userData.dart';

class AdminScreen extends StatefulWidget {
  @override
  _AdminScreenState createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text("Admin Panel"),
        actions: <Widget>[
          Text("\nLog Out", style: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.w400,
              color: Colors.black87),
          ),IconButton(
            onPressed: () => FirebaseAuth.instance.signOut(

            ),
            icon: Icon(Icons.logout_rounded),
            color: Colors.black,
          ),
        ],),

      body:
      Column(

        children: [
          Expanded(
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [

                    Text("Welcome Admin"),
                    SizedBox(height: 50,),


                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => CreateUser()));
                      },
                      child: Container(
                        height: 50,
                        width: 200,
                        color: Colors.blue,
                        child: Center(
                          child: Text(
                            "Create User",
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 30),

                  ElevatedButton(
                  onPressed: () async {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => RealtimeDatabaseInsert()));
                  },child: Container(
                    height: 50,
                    width: 200,
                    color: Colors.blue,
                    child: Center(
                      child: Text(
                        "Division cases",
                      ),
                    ),
                  ),),
                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => addPost()));
                      },child: Container(
                      height: 50,
                      width: 200,
                      color: Colors.blue,
                      child: Center(
                        child: Text(
                          "Add Infographic Post",
                        ),

                      ),
                    ),),
                    SizedBox(height: 30),
                   /* ElevatedButton(
                      onPressed: () async {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => uploadPDF()));
                      },child: Container(
                      height: 50,
                      width: 200,
                      color: Colors.blue,
                      child: Center(
                        child: Text(
                          "Cases Information",
                        ),
                      ),
                    ),),*/
                  ElevatedButton(
                  onPressed: () async {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ListExpose()));
                        },child: Container(
                          height: 50,
                          width: 200,
                          color: Colors.blue,
                          child: Center(
                            child: Text(
                              "Infection Location Cases List Based on Map",
                            ),
                          ),
                  ),),
                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => updateUser3()));
                      },child: Container(
                      height: 50,
                      width: 200,
                      color: Colors.blue,
                      child: Center(
                        child: Text(
                          "View User",
                        ),

                      ),
                    ),),
                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.push(context, MaterialPageRoute(builder: (context) =>MapInfection()));
                      },child: Container(
                      height: 50,
                      width: 200,
                      color: Colors.blue,
                      child: Center(
                        child: Text(
                          "View Map",
                        ),

                      ),
                    ),),  SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: () async {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => uploadPDF()));
                      },child: Container(
                      height: 50,
                      width: 200,
                      color: Colors.blue,
                      child: Center(
                        child: Text(
                          "Upload PDF Information",
                        ),
                      ),
                    ),),
                            ],
                ),
              ),
            ),
          ),
        ],
      ),);

  }




}