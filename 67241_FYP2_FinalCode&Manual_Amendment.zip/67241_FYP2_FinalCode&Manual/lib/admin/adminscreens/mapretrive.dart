//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_geocoder/geocoder.dart'as geoCo;
//need to settle this part first
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

class MapInfection1 extends StatefulWidget {
  @override
  _MapInfection1State createState() => _MapInfection1State();
}

class _MapInfection1State extends State<MapInfection1> {
  late GoogleMapController myController;
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  Position? position;
  String? addressLocation;
  String? country;
  String? postalCode;
  String? city;

  //marker for maps
  void getMarkers(double lat, double long) {
    MarkerId markerId = MarkerId(lat.toString() + long.toString());
    Marker _marker = Marker(
      markerId: markerId,
      position: LatLng(lat, long),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueCyan),
      //    infoWindow: InfoWindow(snippet: addressLocation)
    );
    setState(() {
      markers[markerId] = _marker;
    });
  }

  //get current position
  void getCurrentLocation() async {
    Position currentPosition =
    await GeolocatorPlatform.instance.getCurrentPosition();
    setState(() {
      position = currentPosition;
    });
  }

//call
  @override
  void initState() {
    super.initState();
    getCurrentLocation();
    position = position;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 600.0,
            child: GoogleMap(
              onTap: (tapped) async {
                final coordinated =
                new geoCo.Coordinates(tapped.latitude, tapped.longitude);
                var address = await geoCo.Geocoder.local
                    .findAddressesFromCoordinates(coordinated);

                // tapped.latitude, tapped.longitude);
                var firstAddress = address.first;

                getMarkers(tapped.latitude, tapped.longitude);
                await FirebaseFirestore.instance
                    .collection('location')
                    .add({

                  'latitude': tapped.latitude,
                  'longitude': tapped.longitude,
                  'Address': firstAddress.addressLine,
                  'Country': firstAddress.countryName,
                  'PostalCode': firstAddress.postalCode,
                  'Coords' : GeoPoint(position!.latitude, position!.longitude)

                })
                    .then((value) => print("Location Added"))
                    .catchError(
                        (error) => print("Failed to add Location: $error"));

                setState(() {
                  country = firstAddress.countryName;
                  postalCode = firstAddress.postalCode;
                  addressLocation = firstAddress.addressLine;
                });
              },
              mapType: MapType.hybrid,
              compassEnabled: true,
              trafficEnabled: true,
              initialCameraPosition: CameraPosition(
                  target:LatLng(1.546842, 110.612900), //manual curtrent posittion
                  // target:
                  //    LatLng(position.latitude, position.longitude.toDouble()),
                  zoom: 15.0),
              // Cameraposition
              onMapCreated: (GoogleMapController controller) {
                setState(() {
                  myController = controller;
                });
              },
              markers: Set<Marker>.of(markers.values),
            ),
          ),
          Text('Address : $addressLocation'),
          Text('PostalCode : $postalCode'),
          Text('PostalCode : $country'),
          Text('Address : $country'),
        ],
      ),

      // Google Map
    ); // scaffold
  }

  @override
  void dispose() {
    super.dispose();
  }
}
