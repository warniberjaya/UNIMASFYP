

//import 'dart:html';

class imageData{
  String imgUrl, description;

  imageData(this.imgUrl, this.description);

 Map<String, dynamic> toJson() =>{'imgUrl':imgUrl, 'description': description};
}