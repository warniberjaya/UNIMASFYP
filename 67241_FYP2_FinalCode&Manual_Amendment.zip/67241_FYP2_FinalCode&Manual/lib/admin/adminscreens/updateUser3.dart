import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class updateUser3 extends StatefulWidget {
  const updateUser3({Key? key}) : super(key: key);

  @override
  _updateUser3State createState() => _updateUser3State();
}

class _updateUser3State extends State<updateUser3> {
  final firestoreRef = FirebaseFirestore.instance;
  double heightRow = 10;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("User Account"),
      ),
      body: SafeArea(
        child: FutureBuilder<QuerySnapshot>(
          future: firestoreRef.collection("users").get(),
          builder: (context, snapshot) {

            if (snapshot.hasData) {
              final List<DocumentSnapshot> arrData = snapshot.data!.docs;
              return ListView(
                children: arrData.map((data) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: InkWell(
                      onTap:(){
                        print(data.id);
                        _showUpdateDialog(data, context);
                      } ,
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Column( children: [
                            Text("User Details",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                            SizedBox(height: heightRow+10,),
                            Row(
                              children: [
                              Expanded( flex:1, child: Text("Name")),
                              Expanded(flex:2, child: Text(data['fullName'])),
                            ],),
                            SizedBox(height: heightRow,),
                            Row(
                              children: [
                                Expanded( flex:1, child: Text("Email")),
                                Expanded(flex:2, child: Text(data['emailAdress'])),
                              ],),
                            SizedBox(height: heightRow,),
                            Row(
                              children: [
                                Expanded( flex:1, child: Text("Role")),
                                Expanded(flex:2, child: Text(data['role'])),
                              ],),
                            SizedBox(height: heightRow+10,),
                            OutlinedButton.icon(onPressed: (){
                              deleteRecord(data.id);
                            }, icon: Icon(
                              Icons.delete,
                              color: Colors.red,),
                              label: Text("Delete User"),)
                          ],),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            } else {
              return Text("No Data Found");
            }
          }
        ),
      ),

    );
  }
  //Creating function for delete and passing UniqueKey
  //uniqueKey == documentId/name
  //users->UniqueKey
  Future<void> deleteRecord(String id) async{
    firestoreRef.collection("users").doc(id).delete().then((value) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Record Deleted.")));
    });
  }


  //update user data
  //key
  Future<void> _showUpdateDialog(DocumentSnapshot doc, BuildContext context){
    var fullnameController = new TextEditingController(text: doc['fullName']);
    var emailController = new TextEditingController(text: doc['emailAdress']);
    //var passwordController = new TextEditingController(text: doc['password']);
    var roleController = new TextEditingController(text: doc['role']);
    
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context){
        return AlertDialog(
        title: Text("Update User Info: " + doc.id ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
       children: [

            TextFormField(
              controller: fullnameController,
              decoration: InputDecoration(
             hintText: "Full Name",
                  ),
                  ),
              SizedBox(height: heightRow,),
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(
                hintText: "Email",
                ),
                ),
              /*  SizedBox(height: heightRow,),
                 TextFormField(
                 controller: passwordController,
                 decoration: InputDecoration(
                 hintText: "Password",
              ),
              ),*/
            SizedBox(height: heightRow,),
            TextFormField(
            controller: roleController,
            decoration: InputDecoration(
            hintText: "Role",
            ),
            ),
       ]
    ),
        ),
        actions:[
            TextButton( onPressed: () {
              Navigator.of(context).pop();
        },
          child: Text("Cancel")),
                OutlinedButton(
                  onPressed:(){
              if (fullnameController.text.isNotEmpty &&
                  emailController.text.isNotEmpty &&
                  roleController.text.isNotEmpty
              ){
                //call function
                updateData(
                  doc.id,
                  fullnameController.text,
                  emailController.text,
                    roleController.text,
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Please Enter All Fields Value")));

              }
              },
    child: Text("Update")

        )
            ],
    );
      }
      );
  }


  void updateData(String id, String fullname, String email, String role){
    Map<String, dynamic> data = {
     "fullName": fullname,
     "emailAdress": email,
      "role": role,

    };

    firestoreRef.collection("users").doc(id).update(data).then((value) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Update Successfully")));
    });

  }

}
