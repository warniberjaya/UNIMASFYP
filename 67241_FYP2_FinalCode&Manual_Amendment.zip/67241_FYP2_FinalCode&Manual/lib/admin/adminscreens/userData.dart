

class userInfo {
  String? emailAddress;
  String? fullName;
  String? role;
  String? password;

  userInfo();
  Map<String, dynamic>toJson() => {'emailAdress': emailAddress, 'fullName':fullName, 'role':role, 'password':password};

  userInfo.fromSnapshot(snapshot)
  : emailAddress = snapshot.data()['emailAddress'],
    fullName = snapshot.data()['fullName'],
    role = snapshot.data()['role'],
    password = snapshot.data()['password'].toString();
}


