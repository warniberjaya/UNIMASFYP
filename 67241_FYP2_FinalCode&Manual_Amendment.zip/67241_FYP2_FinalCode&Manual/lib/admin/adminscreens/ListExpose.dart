import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ListExpose extends StatefulWidget {
  const ListExpose({Key? key}) : super(key: key);

  @override
  _ListExposeState createState() => _ListExposeState();
}

class _ListExposeState extends State<ListExpose> {
  final firestoreRef = FirebaseFirestore.instance;
  double heightRow = 10;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Expose Location"),
      ),
      body: SafeArea(
        child: FutureBuilder<QuerySnapshot>(
            future: firestoreRef.collection("location").get(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                final List<DocumentSnapshot> arrData = snapshot.data!.docs;
                return ListView(
                  children: arrData.map((data) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: InkWell(
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Column(children: [
                              Text("Location",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                              SizedBox(height: heightRow + 10,),
                              Row(
                                children: [
                                  Expanded(flex: 1, child: Text("Address")),
                                  Expanded(
                                      flex: 2, child: Text(data['Address'])),
                                ],),
                              SizedBox(height: heightRow,),
                              Row(
                                children: [
                                  Expanded(flex: 1, child: Text("Country")),
                                  Expanded(
                                      flex: 2, child: Text(data['Country'])),
                                ],),
                              SizedBox(height: heightRow,),
                              Row(
                                children: [
                                  Expanded(flex: 1, child: Text("Postal Code")),
                                  Expanded(flex: 2,
                                      child: Text(data['PostalCode'])),
                                ],),
                              SizedBox(height: heightRow + 10,),
                              OutlinedButton.icon(onPressed: (){
                                deleteRecord(data.id);
                              }, icon: Icon(
                                Icons.delete,
                                color: Colors.red,),
                                label: Text("Delete Location"),)
                            ],),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                );
              } else {
                return Text("No Data Found");
              }
            }
        ),
      ),

    );
  }
  Future<void> deleteRecord(String id) async{
    firestoreRef.collection("location").doc(id).delete().then((value) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Record Deleted.")));
    });
  }


}
