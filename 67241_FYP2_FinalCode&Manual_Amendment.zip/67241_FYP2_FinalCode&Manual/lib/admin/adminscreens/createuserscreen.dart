
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../widgets/my_buttonSignInOut.dart';
import 'package:covid19_info/user/signup/signup_auth_provider.dart';

import '../services/auth_Services.dart';



class CreateUser extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<CreateUser> {
  TextEditingController fullnameController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  //TextEditingController roleController = new TextEditingController();


  @override
  Widget build(BuildContext context) {
    SignupAuthCreateUserProvider signupAuthProvider =
    Provider.of<SignupAuthCreateUserProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Create User'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
        TextFormField(
        controller: fullnameController,
        decoration: InputDecoration(
          hintText: "Full Name",
        ),
      ),
         TextFormField(
            controller: emailController,
            decoration: InputDecoration(
              hintText: "Email",
            ),
          ),

          TextFormField(
            controller: passwordController,
            decoration: InputDecoration(
              hintText: "Password",
            ),
          ),

          Column(
              children: [
              signupAuthProvider.loading == false
              ?  GestureDetector(
                onTap: () async{
                signupAuthProvider.signupVaidation(
                fullName: fullnameController,
                context: context,
                emailAdress: emailController,
                password: passwordController,
            //    role: roleController,

                );
            },
                child: Container(
                  height: 50,
                  width: 100,
                  color: Colors.blue,
                  child: Center(
                    child: Text(
                      "Create User",
                    ),
                  ),
                ),)

              : Center(
                child: CircularProgressIndicator(),
              ),
                SizedBox(
                  height: 20,
                ),]
            ),
            ]),
          );

  }
}