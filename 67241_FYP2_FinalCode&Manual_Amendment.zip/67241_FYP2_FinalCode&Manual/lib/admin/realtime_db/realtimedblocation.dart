import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class RealtimeDatabaseInsert extends StatefulWidget {
  const RealtimeDatabaseInsert({Key? key}) : super(key: key);

  @override
  _RealtimeDatabaseInsertState createState() => _RealtimeDatabaseInsertState();
}

class _RealtimeDatabaseInsertState extends State<RealtimeDatabaseInsert> {
  //create controller
  var casesInfoController = new TextEditingController();
  var cityController = new TextEditingController();
  var postalCodeController = new TextEditingController();
  var divisionController = new TextEditingController();

  final databaseRef = FirebaseDatabase.instance.ref();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Location cases'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: SingleChildScrollView(
            child: Column( children: [
            SizedBox(height: 50,),
            Text("Insert Infection Division Cases Data", style: TextStyle(fontSize: 28),),

            SizedBox(height: 30,),

              SizedBox(height: 15,),
              TextFormField(
                controller: casesInfoController,
                decoration: InputDecoration(labelText: 'Cases', border: OutlineInputBorder()),
              ),

            SizedBox(height: 15,),
            TextFormField(
              controller: cityController,
              decoration: InputDecoration(labelText: 'City', border: OutlineInputBorder()),
            ),

            SizedBox(height: 15,),
            TextFormField(
              controller: postalCodeController,
              decoration: InputDecoration(labelText: 'PostalCode', border: OutlineInputBorder()),
            ),

            SizedBox(height: 15,),
            TextFormField(
              controller: divisionController,
              decoration: InputDecoration(labelText: 'Division', border: OutlineInputBorder()),
            ),
            
              SizedBox(height: 50,),
              OutlinedButton(onPressed: (){
                //calling function passing value of controller
                if(casesInfoController.text.isNotEmpty && cityController.text.isNotEmpty && postalCodeController.text.isNotEmpty && divisionController.text.isNotEmpty){
                  insertData(casesInfoController.text, cityController.text, postalCodeController.text, divisionController.text);
                }
              }, child: Text("Add", style: TextStyle(fontSize: 18),))
      ],
      ),
          ),
        ),),
    );
  }
  void insertData(String casesInfo, String city, String postalCode, String division){
    String? key = databaseRef.child("Case").push().key;
    //create location->infectionlocation->data
       databaseRef.child("Cases").child(key!).set({
         'id': key,
      'case':casesInfo,
      'city': city,
      'postalCode':postalCode,
      'division':division,
    }
    );
    casesInfoController.clear();
    cityController.clear();
    postalCodeController.clear();
    divisionController.clear();

  }
}
