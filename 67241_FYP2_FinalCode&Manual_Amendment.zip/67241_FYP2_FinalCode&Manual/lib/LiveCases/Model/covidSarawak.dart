import 'dart:convert';
/// currentVersion : 10.71
/// cimVersion : "2.4.0"
/// id : 0
/// name : "mougis.sde.Sarawak_COVID19"
/// type : "Feature Layer"
/// parentLayer : null
/// defaultVisibility : true
/// minScale : 0
/// maxScale : 0
/// geometryType : "esriGeometryPoint"
/// description : ""
/// copyrightText : ""
/// editFieldsInfo : null
/// ownershipBasedAccessControlForFeatures : null
/// syncCanReturnChanges : false
/// relationships : []
/// isDataVersioned : false
/// isDataArchived : false
/// isDataBranchVersioned : false
/// isCoGoEnabled : false
/// supportsRollbackOnFailureParameter : true
/// archivingInfo : {"supportsQueryWithHistoricMoment":false,"startArchivingMoment":-1}
/// supportsStatistics : true
/// supportsAdvancedQueries : true
/// supportsValidateSQL : true
/// supportsCoordinatesQuantization : true
/// supportsCalculate : true
/// advancedQueryCapabilities : {"supportsPagination":true,"supportsTrueCurve":true,"supportsQueryWithDistance":true,"supportsReturningQueryExtent":true,"supportsStatistics":true,"supportsHavingClause":true,"supportsOrderBy":true,"supportsDistinct":true,"supportsCountDistinct":true,"supportsQueryWithResultType":true,"supportsReturningGeometryCentroid":false,"supportsSqlExpression":true}
/// hasMetadata : true
/// extent : {"xmin":114.13981543400007,"ymin":3.0195137160000627,"xmax":114.13981543400007,"ymax":3.0195137160000627,"spatialReference":{"wkid":4326,"latestWkid":4326,"xyTolerance":8.983152841195215E-9,"zTolerance":0.001,"mTolerance":0.001,"falseX":-400,"falseY":-400,"xyUnits":9.999999999999999E8,"falseZ":-100000,"zUnits":10000,"falseM":-100000,"mUnits":10000}}
/// sourceSpatialReference : {"wkid":4326,"latestWkid":4326,"xyTolerance":8.983152841195215E-9,"zTolerance":0.001,"mTolerance":0.001,"falseX":-400,"falseY":-400,"xyUnits":9.999999999999999E8,"falseZ":-100000,"zUnits":10000,"falseM":-100000,"mUnits":10000}
/// drawingInfo : {"renderer":{"type":"simple","symbol":{"type":"esriSMS","style":"esriSMSCircle","color":[181,213,252,255],"size":4,"angle":0,"xoffset":0,"yoffset":0,"outline":{"color":[0,0,0,255],"width":0.7}}},"scaleSymbols":true,"transparency":0,"labelingInfo":null}
/// hasM : false
/// hasZ : false
/// allowGeometryUpdates : true
/// allowTrueCurvesUpdates : true
/// onlyAllowTrueCurveUpdatesByTrueCurveClients : true
/// hasAttachments : false
/// supportsApplyEditsWithGlobalIds : false
/// htmlPopupType : "esriServerHTMLPopupTypeAsHTMLText"
/// objectIdField : "objectid"
/// globalIdField : ""
/// displayField : "date"
/// typeIdField : ""
/// subtypeField : ""
/// fields : [{"name":"objectid","type":"esriFieldTypeOID","alias":"objectid","domain":null,"editable":false,"nullable":false,"defaultValue":null,"modelName":"objectid"},{"name":"date","type":"esriFieldTypeDate","alias":"DATE","domain":null,"editable":true,"nullable":true,"length":8,"defaultValue":null,"modelName":"date"},{"name":"division_positive","type":"esriFieldTypeString","alias":"DIVISION_POSITIVE","domain":null,"editable":true,"nullable":true,"length":1073741822,"defaultValue":null,"modelName":"division_positive"},{"name":"number_deaths","type":"esriFieldTypeInteger","alias":"NUMBER_DEATHS","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"number_deaths"},{"name":"accumulated_deaths","type":"esriFieldTypeInteger","alias":"ACCUMULATED_DEATHS","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"accumulated_deaths"},{"name":"division_death","type":"esriFieldTypeString","alias":"DIVISION_DEATH","domain":null,"editable":true,"nullable":true,"length":1073741822,"defaultValue":null,"modelName":"division_death"},{"name":"remarks","type":"esriFieldTypeString","alias":"REMARKS","domain":null,"editable":true,"nullable":true,"length":1073741822,"defaultValue":null,"modelName":"remarks"},{"name":"point_x","type":"esriFieldTypeDouble","alias":"POINT_X","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"point_x"},{"name":"point_y","type":"esriFieldTypeDouble","alias":"POINT_Y","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"point_y"},{"name":"accumulated_positive_cases","type":"esriFieldTypeInteger","alias":"ACCUMULATED POSITIVE CASES","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"accumulated_positive_cases"},{"name":"daily_positive_cases","type":"esriFieldTypeInteger","alias":"DAILY POSITIVE CASES","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"daily_positive_cases"},{"name":"daily_puis","type":"esriFieldTypeInteger","alias":"DAILY PUIs","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"daily_puis"},{"name":"accumulated_puis","type":"esriFieldTypeInteger","alias":"ACCUMULATED PUIs","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"accumulated_puis"},{"name":"accumulated_recovered","type":"esriFieldTypeInteger","alias":"Accumulated Discharged/Recovered","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"accumulated_recovered"},{"name":"date1","type":"esriFieldTypeDate","alias":"Date1","domain":null,"editable":true,"nullable":true,"length":8,"defaultValue":null,"modelName":"date1"}]
/// geometryField : {"name":"shape","type":"esriFieldTypeGeometry","alias":"shape","domain":null,"editable":true,"nullable":true,"defaultValue":null,"modelName":"shape"}
/// indexes : [{"name":"r56_sde_rowid_uk","fields":"objectid","isAscending":true,"isUnique":true,"description":""},{"name":"a44_ix1","fields":"shape","isAscending":true,"isUnique":true,"description":""}]
/// dateFieldsTimeReference : {"timeZone":"UTC","respectsDaylightSaving":false}
/// types : []
/// templates : [{"name":"mougis.sde.Sarawak_COVID19","description":"","prototype":{"attributes":{"accumulated_recovered":null,"date1":null,"date":null,"division_positive":null,"number_deaths":null,"accumulated_deaths":null,"division_death":null,"remarks":null,"point_x":null,"point_y":null,"accumulated_positive_cases":null,"daily_positive_cases":null,"daily_puis":null,"accumulated_puis":null}},"drawingTool":"esriFeatureEditToolPoint"}]
/// maxRecordCount : 2000
/// supportedQueryFormats : "JSON, geoJSON, PBF"
/// capabilities : "Query,Create,Update,Delete,Uploads,Editing"
/// useStandardizedQueries : true
/// standardMaxRecordCount : 32000
/// tileMaxRecordCount : 8000
/// maxRecordCountFactor : 1

CovidSarawak covidSarawakFromJson(String str) => CovidSarawak.fromJson(json.decode(str));
String covidSarawakToJson(CovidSarawak data) => json.encode(data.toJson());
class CovidSarawak {
  CovidSarawak({
      double? currentVersion, 
      String? cimVersion, 
      int? id, 
      String? name, 
      String? type, 
      dynamic parentLayer, 
      bool? defaultVisibility, 
      int? minScale, 
      int? maxScale, 
      String? geometryType, 
      String? description, 
      String? copyrightText, 
      dynamic editFieldsInfo, 
      dynamic ownershipBasedAccessControlForFeatures, 
      bool? syncCanReturnChanges, 
      List<dynamic>? relationships, 
      bool? isDataVersioned, 
      bool? isDataArchived, 
      bool? isDataBranchVersioned, 
      bool? isCoGoEnabled, 
      bool? supportsRollbackOnFailureParameter, 
      ArchivingInfo? archivingInfo, 
      bool? supportsStatistics, 
      bool? supportsAdvancedQueries, 
      bool? supportsValidateSQL, 
      bool? supportsCoordinatesQuantization, 
      bool? supportsCalculate, 
      AdvancedQueryCapabilities? advancedQueryCapabilities, 
      bool? hasMetadata, 
      Extent? extent, 
      SourceSpatialReference? sourceSpatialReference, 
      DrawingInfo? drawingInfo, 
      bool? hasM, 
      bool? hasZ, 
      bool? allowGeometryUpdates, 
      bool? allowTrueCurvesUpdates, 
      bool? onlyAllowTrueCurveUpdatesByTrueCurveClients, 
      bool? hasAttachments, 
      bool? supportsApplyEditsWithGlobalIds, 
      String? htmlPopupType, 
      String? objectIdField, 
      String? globalIdField, 
      String? displayField, 
      String? typeIdField, 
      String? subtypeField, 
      List<Fields>? fields, 
      GeometryField? geometryField, 
      List<Indexes>? indexes, 
      DateFieldsTimeReference? dateFieldsTimeReference, 
      List<dynamic>? types, 
      List<Templates>? templates, 
      int? maxRecordCount, 
      String? supportedQueryFormats, 
      String? capabilities, 
      bool? useStandardizedQueries, 
      int? standardMaxRecordCount, 
      int? tileMaxRecordCount, 
      int? maxRecordCountFactor,}){
    _currentVersion = currentVersion;
    _cimVersion = cimVersion;
    _id = id;
    _name = name;
    _type = type;
    _parentLayer = parentLayer;
    _defaultVisibility = defaultVisibility;
    _minScale = minScale;
    _maxScale = maxScale;
    _geometryType = geometryType;
    _description = description;
    _copyrightText = copyrightText;
    _editFieldsInfo = editFieldsInfo;
    _ownershipBasedAccessControlForFeatures = ownershipBasedAccessControlForFeatures;
    _syncCanReturnChanges = syncCanReturnChanges;
    _relationships = relationships;
    _isDataVersioned = isDataVersioned;
    _isDataArchived = isDataArchived;
    _isDataBranchVersioned = isDataBranchVersioned;
    _isCoGoEnabled = isCoGoEnabled;
    _supportsRollbackOnFailureParameter = supportsRollbackOnFailureParameter;
    _archivingInfo = archivingInfo;
    _supportsStatistics = supportsStatistics;
    _supportsAdvancedQueries = supportsAdvancedQueries;
    _supportsValidateSQL = supportsValidateSQL;
    _supportsCoordinatesQuantization = supportsCoordinatesQuantization;
    _supportsCalculate = supportsCalculate;
    _advancedQueryCapabilities = advancedQueryCapabilities;
    _hasMetadata = hasMetadata;
    _extent = extent;
    _sourceSpatialReference = sourceSpatialReference;
    _drawingInfo = drawingInfo;
    _hasM = hasM;
    _hasZ = hasZ;
    _allowGeometryUpdates = allowGeometryUpdates;
    _allowTrueCurvesUpdates = allowTrueCurvesUpdates;
    _onlyAllowTrueCurveUpdatesByTrueCurveClients = onlyAllowTrueCurveUpdatesByTrueCurveClients;
    _hasAttachments = hasAttachments;
    _supportsApplyEditsWithGlobalIds = supportsApplyEditsWithGlobalIds;
    _htmlPopupType = htmlPopupType;
    _objectIdField = objectIdField;
    _globalIdField = globalIdField;
    _displayField = displayField;
    _typeIdField = typeIdField;
    _subtypeField = subtypeField;
    _fields = fields;
    _geometryField = geometryField;
    _indexes = indexes;
    _dateFieldsTimeReference = dateFieldsTimeReference;
    _types = types;
    _templates = templates;
    _maxRecordCount = maxRecordCount;
    _supportedQueryFormats = supportedQueryFormats;
    _capabilities = capabilities;
    _useStandardizedQueries = useStandardizedQueries;
    _standardMaxRecordCount = standardMaxRecordCount;
    _tileMaxRecordCount = tileMaxRecordCount;
    _maxRecordCountFactor = maxRecordCountFactor;
}

  CovidSarawak.fromJson(dynamic json) {
    _currentVersion = json['currentVersion'];
    _cimVersion = json['cimVersion'];
    _id = json['id'];
    _name = json['name'];
    _type = json['type'];
    _parentLayer = json['parentLayer'];
    _defaultVisibility = json['defaultVisibility'];
    _minScale = json['minScale'];
    _maxScale = json['maxScale'];
    _geometryType = json['geometryType'];
    _description = json['description'];
    _copyrightText = json['copyrightText'];
    _editFieldsInfo = json['editFieldsInfo'];
    _ownershipBasedAccessControlForFeatures = json['ownershipBasedAccessControlForFeatures'];
    _syncCanReturnChanges = json['syncCanReturnChanges'];
    if (json['relationships'] != null) {
      _relationships = [];
      json['relationships'].forEach((v) {
        _relationships?.add((v));
      });
    }
    _isDataVersioned = json['isDataVersioned'];
    _isDataArchived = json['isDataArchived'];
    _isDataBranchVersioned = json['isDataBranchVersioned'];
    _isCoGoEnabled = json['isCoGoEnabled'];
    _supportsRollbackOnFailureParameter = json['supportsRollbackOnFailureParameter'];
    _archivingInfo = json['archivingInfo'] != null ? ArchivingInfo.fromJson(json['archivingInfo']) : null;
    _supportsStatistics = json['supportsStatistics'];
    _supportsAdvancedQueries = json['supportsAdvancedQueries'];
    _supportsValidateSQL = json['supportsValidateSQL'];
    _supportsCoordinatesQuantization = json['supportsCoordinatesQuantization'];
    _supportsCalculate = json['supportsCalculate'];
    _advancedQueryCapabilities = json['advancedQueryCapabilities'] != null ? AdvancedQueryCapabilities.fromJson(json['advancedQueryCapabilities']) : null;
    _hasMetadata = json['hasMetadata'];
    _extent = json['extent'] != null ? Extent.fromJson(json['extent']) : null;
    _sourceSpatialReference = json['sourceSpatialReference'] != null ? SourceSpatialReference.fromJson(json['sourceSpatialReference']) : null;
    _drawingInfo = json['drawingInfo'] != null ? DrawingInfo.fromJson(json['drawingInfo']) : null;
    _hasM = json['hasM'];
    _hasZ = json['hasZ'];
    _allowGeometryUpdates = json['allowGeometryUpdates'];
    _allowTrueCurvesUpdates = json['allowTrueCurvesUpdates'];
    _onlyAllowTrueCurveUpdatesByTrueCurveClients = json['onlyAllowTrueCurveUpdatesByTrueCurveClients'];
    _hasAttachments = json['hasAttachments'];
    _supportsApplyEditsWithGlobalIds = json['supportsApplyEditsWithGlobalIds'];
    _htmlPopupType = json['htmlPopupType'];
    _objectIdField = json['objectIdField'];
    _globalIdField = json['globalIdField'];
    _displayField = json['displayField'];
    _typeIdField = json['typeIdField'];
    _subtypeField = json['subtypeField'];
    if (json['fields'] != null) {
      _fields = [];
      json['fields'].forEach((v) {
        _fields?.add(Fields.fromJson(v));
      });
    }
    _geometryField = json['geometryField'] != null ? GeometryField.fromJson(json['geometryField']) : null;
    if (json['indexes'] != null) {
      _indexes = [];
      json['indexes'].forEach((v) {
        _indexes?.add(Indexes.fromJson(v));
      });
    }
    _dateFieldsTimeReference = json['dateFieldsTimeReference'] != null ? DateFieldsTimeReference.fromJson(json['dateFieldsTimeReference']) : null;
    if (json['types'] != null) {
      _types = [];
      json['types'].forEach((v) {
        _types?.add((v));
      });
    }
    if (json['templates'] != null) {
      _templates = [];
      json['templates'].forEach((v) {
        _templates?.add(Templates.fromJson(v));
      });
    }
    _maxRecordCount = json['maxRecordCount'];
    _supportedQueryFormats = json['supportedQueryFormats'];
    _capabilities = json['capabilities'];
    _useStandardizedQueries = json['useStandardizedQueries'];
    _standardMaxRecordCount = json['standardMaxRecordCount'];
    _tileMaxRecordCount = json['tileMaxRecordCount'];
    _maxRecordCountFactor = json['maxRecordCountFactor'];
  }
  double? _currentVersion;
  String? _cimVersion;
  int? _id;
  String? _name;
  String? _type;
  dynamic _parentLayer;
  bool? _defaultVisibility;
  int? _minScale;
  int? _maxScale;
  String? _geometryType;
  String? _description;
  String? _copyrightText;
  dynamic _editFieldsInfo;
  dynamic _ownershipBasedAccessControlForFeatures;
  bool? _syncCanReturnChanges;
  List<dynamic>? _relationships;
  bool? _isDataVersioned;
  bool? _isDataArchived;
  bool? _isDataBranchVersioned;
  bool? _isCoGoEnabled;
  bool? _supportsRollbackOnFailureParameter;
  ArchivingInfo? _archivingInfo;
  bool? _supportsStatistics;
  bool? _supportsAdvancedQueries;
  bool? _supportsValidateSQL;
  bool? _supportsCoordinatesQuantization;
  bool? _supportsCalculate;
  AdvancedQueryCapabilities? _advancedQueryCapabilities;
  bool? _hasMetadata;
  Extent? _extent;
  SourceSpatialReference? _sourceSpatialReference;
  DrawingInfo? _drawingInfo;
  bool? _hasM;
  bool? _hasZ;
  bool? _allowGeometryUpdates;
  bool? _allowTrueCurvesUpdates;
  bool? _onlyAllowTrueCurveUpdatesByTrueCurveClients;
  bool? _hasAttachments;
  bool? _supportsApplyEditsWithGlobalIds;
  String? _htmlPopupType;
  String? _objectIdField;
  String? _globalIdField;
  String? _displayField;
  String? _typeIdField;
  String? _subtypeField;
  List<Fields>? _fields;
  GeometryField? _geometryField;
  List<Indexes>? _indexes;
  DateFieldsTimeReference? _dateFieldsTimeReference;
  List<dynamic>? _types;
  List<Templates>? _templates;
  int? _maxRecordCount;
  String? _supportedQueryFormats;
  String? _capabilities;
  bool? _useStandardizedQueries;
  int? _standardMaxRecordCount;
  int? _tileMaxRecordCount;
  int? _maxRecordCountFactor;
CovidSarawak copyWith({  double? currentVersion,
  String? cimVersion,
  int? id,
  String? name,
  String? type,
  dynamic parentLayer,
  bool? defaultVisibility,
  int? minScale,
  int? maxScale,
  String? geometryType,
  String? description,
  String? copyrightText,
  dynamic editFieldsInfo,
  dynamic ownershipBasedAccessControlForFeatures,
  bool? syncCanReturnChanges,
  List<dynamic>? relationships,
  bool? isDataVersioned,
  bool? isDataArchived,
  bool? isDataBranchVersioned,
  bool? isCoGoEnabled,
  bool? supportsRollbackOnFailureParameter,
  ArchivingInfo? archivingInfo,
  bool? supportsStatistics,
  bool? supportsAdvancedQueries,
  bool? supportsValidateSQL,
  bool? supportsCoordinatesQuantization,
  bool? supportsCalculate,
  AdvancedQueryCapabilities? advancedQueryCapabilities,
  bool? hasMetadata,
  Extent? extent,
  SourceSpatialReference? sourceSpatialReference,
  DrawingInfo? drawingInfo,
  bool? hasM,
  bool? hasZ,
  bool? allowGeometryUpdates,
  bool? allowTrueCurvesUpdates,
  bool? onlyAllowTrueCurveUpdatesByTrueCurveClients,
  bool? hasAttachments,
  bool? supportsApplyEditsWithGlobalIds,
  String? htmlPopupType,
  String? objectIdField,
  String? globalIdField,
  String? displayField,
  String? typeIdField,
  String? subtypeField,
  List<Fields>? fields,
  GeometryField? geometryField,
  List<Indexes>? indexes,
  DateFieldsTimeReference? dateFieldsTimeReference,
  List<dynamic>? types,
  List<Templates>? templates,
  int? maxRecordCount,
  String? supportedQueryFormats,
  String? capabilities,
  bool? useStandardizedQueries,
  int? standardMaxRecordCount,
  int? tileMaxRecordCount,
  int? maxRecordCountFactor,
}) => CovidSarawak(  currentVersion: currentVersion ?? _currentVersion,
  cimVersion: cimVersion ?? _cimVersion,
  id: id ?? _id,
  name: name ?? _name,
  type: type ?? _type,
  parentLayer: parentLayer ?? _parentLayer,
  defaultVisibility: defaultVisibility ?? _defaultVisibility,
  minScale: minScale ?? _minScale,
  maxScale: maxScale ?? _maxScale,
  geometryType: geometryType ?? _geometryType,
  description: description ?? _description,
  copyrightText: copyrightText ?? _copyrightText,
  editFieldsInfo: editFieldsInfo ?? _editFieldsInfo,
  ownershipBasedAccessControlForFeatures: ownershipBasedAccessControlForFeatures ?? _ownershipBasedAccessControlForFeatures,
  syncCanReturnChanges: syncCanReturnChanges ?? _syncCanReturnChanges,
  relationships: relationships ?? _relationships,
  isDataVersioned: isDataVersioned ?? _isDataVersioned,
  isDataArchived: isDataArchived ?? _isDataArchived,
  isDataBranchVersioned: isDataBranchVersioned ?? _isDataBranchVersioned,
  isCoGoEnabled: isCoGoEnabled ?? _isCoGoEnabled,
  supportsRollbackOnFailureParameter: supportsRollbackOnFailureParameter ?? _supportsRollbackOnFailureParameter,
  archivingInfo: archivingInfo ?? _archivingInfo,
  supportsStatistics: supportsStatistics ?? _supportsStatistics,
  supportsAdvancedQueries: supportsAdvancedQueries ?? _supportsAdvancedQueries,
  supportsValidateSQL: supportsValidateSQL ?? _supportsValidateSQL,
  supportsCoordinatesQuantization: supportsCoordinatesQuantization ?? _supportsCoordinatesQuantization,
  supportsCalculate: supportsCalculate ?? _supportsCalculate,
  advancedQueryCapabilities: advancedQueryCapabilities ?? _advancedQueryCapabilities,
  hasMetadata: hasMetadata ?? _hasMetadata,
  extent: extent ?? _extent,
  sourceSpatialReference: sourceSpatialReference ?? _sourceSpatialReference,
  drawingInfo: drawingInfo ?? _drawingInfo,
  hasM: hasM ?? _hasM,
  hasZ: hasZ ?? _hasZ,
  allowGeometryUpdates: allowGeometryUpdates ?? _allowGeometryUpdates,
  allowTrueCurvesUpdates: allowTrueCurvesUpdates ?? _allowTrueCurvesUpdates,
  onlyAllowTrueCurveUpdatesByTrueCurveClients: onlyAllowTrueCurveUpdatesByTrueCurveClients ?? _onlyAllowTrueCurveUpdatesByTrueCurveClients,
  hasAttachments: hasAttachments ?? _hasAttachments,
  supportsApplyEditsWithGlobalIds: supportsApplyEditsWithGlobalIds ?? _supportsApplyEditsWithGlobalIds,
  htmlPopupType: htmlPopupType ?? _htmlPopupType,
  objectIdField: objectIdField ?? _objectIdField,
  globalIdField: globalIdField ?? _globalIdField,
  displayField: displayField ?? _displayField,
  typeIdField: typeIdField ?? _typeIdField,
  subtypeField: subtypeField ?? _subtypeField,
  fields: fields ?? _fields,
  geometryField: geometryField ?? _geometryField,
  indexes: indexes ?? _indexes,
  dateFieldsTimeReference: dateFieldsTimeReference ?? _dateFieldsTimeReference,
  types: types ?? _types,
  templates: templates ?? _templates,
  maxRecordCount: maxRecordCount ?? _maxRecordCount,
  supportedQueryFormats: supportedQueryFormats ?? _supportedQueryFormats,
  capabilities: capabilities ?? _capabilities,
  useStandardizedQueries: useStandardizedQueries ?? _useStandardizedQueries,
  standardMaxRecordCount: standardMaxRecordCount ?? _standardMaxRecordCount,
  tileMaxRecordCount: tileMaxRecordCount ?? _tileMaxRecordCount,
  maxRecordCountFactor: maxRecordCountFactor ?? _maxRecordCountFactor,
);
  double? get currentVersion => _currentVersion;
  String? get cimVersion => _cimVersion;
  int? get id => _id;
  String? get name => _name;
  String? get type => _type;
  dynamic get parentLayer => _parentLayer;
  bool? get defaultVisibility => _defaultVisibility;
  int? get minScale => _minScale;
  int? get maxScale => _maxScale;
  String? get geometryType => _geometryType;
  String? get description => _description;
  String? get copyrightText => _copyrightText;
  dynamic get editFieldsInfo => _editFieldsInfo;
  dynamic get ownershipBasedAccessControlForFeatures => _ownershipBasedAccessControlForFeatures;
  bool? get syncCanReturnChanges => _syncCanReturnChanges;
  List<dynamic>? get relationships => _relationships;
  bool? get isDataVersioned => _isDataVersioned;
  bool? get isDataArchived => _isDataArchived;
  bool? get isDataBranchVersioned => _isDataBranchVersioned;
  bool? get isCoGoEnabled => _isCoGoEnabled;
  bool? get supportsRollbackOnFailureParameter => _supportsRollbackOnFailureParameter;
  ArchivingInfo? get archivingInfo => _archivingInfo;
  bool? get supportsStatistics => _supportsStatistics;
  bool? get supportsAdvancedQueries => _supportsAdvancedQueries;
  bool? get supportsValidateSQL => _supportsValidateSQL;
  bool? get supportsCoordinatesQuantization => _supportsCoordinatesQuantization;
  bool? get supportsCalculate => _supportsCalculate;
  AdvancedQueryCapabilities? get advancedQueryCapabilities => _advancedQueryCapabilities;
  bool? get hasMetadata => _hasMetadata;
  Extent? get extent => _extent;
  SourceSpatialReference? get sourceSpatialReference => _sourceSpatialReference;
  DrawingInfo? get drawingInfo => _drawingInfo;
  bool? get hasM => _hasM;
  bool? get hasZ => _hasZ;
  bool? get allowGeometryUpdates => _allowGeometryUpdates;
  bool? get allowTrueCurvesUpdates => _allowTrueCurvesUpdates;
  bool? get onlyAllowTrueCurveUpdatesByTrueCurveClients => _onlyAllowTrueCurveUpdatesByTrueCurveClients;
  bool? get hasAttachments => _hasAttachments;
  bool? get supportsApplyEditsWithGlobalIds => _supportsApplyEditsWithGlobalIds;
  String? get htmlPopupType => _htmlPopupType;
  String? get objectIdField => _objectIdField;
  String? get globalIdField => _globalIdField;
  String? get displayField => _displayField;
  String? get typeIdField => _typeIdField;
  String? get subtypeField => _subtypeField;
  List<Fields>? get fields => _fields;
  GeometryField? get geometryField => _geometryField;
  List<Indexes>? get indexes => _indexes;
  DateFieldsTimeReference? get dateFieldsTimeReference => _dateFieldsTimeReference;
  List<dynamic>? get types => _types;
  List<Templates>? get templates => _templates;
  int? get maxRecordCount => _maxRecordCount;
  String? get supportedQueryFormats => _supportedQueryFormats;
  String? get capabilities => _capabilities;
  bool? get useStandardizedQueries => _useStandardizedQueries;
  int? get standardMaxRecordCount => _standardMaxRecordCount;
  int? get tileMaxRecordCount => _tileMaxRecordCount;
  int? get maxRecordCountFactor => _maxRecordCountFactor;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['currentVersion'] = _currentVersion;
    map['cimVersion'] = _cimVersion;
    map['id'] = _id;
    map['name'] = _name;
    map['type'] = _type;
    map['parentLayer'] = _parentLayer;
    map['defaultVisibility'] = _defaultVisibility;
    map['minScale'] = _minScale;
    map['maxScale'] = _maxScale;
    map['geometryType'] = _geometryType;
    map['description'] = _description;
    map['copyrightText'] = _copyrightText;
    map['editFieldsInfo'] = _editFieldsInfo;
    map['ownershipBasedAccessControlForFeatures'] = _ownershipBasedAccessControlForFeatures;
    map['syncCanReturnChanges'] = _syncCanReturnChanges;
    if (_relationships != null) {
      map['relationships'] = _relationships?.map((v) => v.toJson()).toList();
    }
    map['isDataVersioned'] = _isDataVersioned;
    map['isDataArchived'] = _isDataArchived;
    map['isDataBranchVersioned'] = _isDataBranchVersioned;
    map['isCoGoEnabled'] = _isCoGoEnabled;
    map['supportsRollbackOnFailureParameter'] = _supportsRollbackOnFailureParameter;
    if (_archivingInfo != null) {
      map['archivingInfo'] = _archivingInfo?.toJson();
    }
    map['supportsStatistics'] = _supportsStatistics;
    map['supportsAdvancedQueries'] = _supportsAdvancedQueries;
    map['supportsValidateSQL'] = _supportsValidateSQL;
    map['supportsCoordinatesQuantization'] = _supportsCoordinatesQuantization;
    map['supportsCalculate'] = _supportsCalculate;
    if (_advancedQueryCapabilities != null) {
      map['advancedQueryCapabilities'] = _advancedQueryCapabilities?.toJson();
    }
    map['hasMetadata'] = _hasMetadata;
    if (_extent != null) {
      map['extent'] = _extent?.toJson();
    }
    if (_sourceSpatialReference != null) {
      map['sourceSpatialReference'] = _sourceSpatialReference?.toJson();
    }
    if (_drawingInfo != null) {
      map['drawingInfo'] = _drawingInfo?.toJson();
    }
    map['hasM'] = _hasM;
    map['hasZ'] = _hasZ;
    map['allowGeometryUpdates'] = _allowGeometryUpdates;
    map['allowTrueCurvesUpdates'] = _allowTrueCurvesUpdates;
    map['onlyAllowTrueCurveUpdatesByTrueCurveClients'] = _onlyAllowTrueCurveUpdatesByTrueCurveClients;
    map['hasAttachments'] = _hasAttachments;
    map['supportsApplyEditsWithGlobalIds'] = _supportsApplyEditsWithGlobalIds;
    map['htmlPopupType'] = _htmlPopupType;
    map['objectIdField'] = _objectIdField;
    map['globalIdField'] = _globalIdField;
    map['displayField'] = _displayField;
    map['typeIdField'] = _typeIdField;
    map['subtypeField'] = _subtypeField;
    if (_fields != null) {
      map['fields'] = _fields?.map((v) => v.toJson()).toList();
    }
    if (_geometryField != null) {
      map['geometryField'] = _geometryField?.toJson();
    }
    if (_indexes != null) {
      map['indexes'] = _indexes?.map((v) => v.toJson()).toList();
    }
    if (_dateFieldsTimeReference != null) {
      map['dateFieldsTimeReference'] = _dateFieldsTimeReference?.toJson();
    }
    if (_types != null) {
      map['types'] = _types?.map((v) => v.toJson()).toList();
    }
    if (_templates != null) {
      map['templates'] = _templates?.map((v) => v.toJson()).toList();
    }
    map['maxRecordCount'] = _maxRecordCount;
    map['supportedQueryFormats'] = _supportedQueryFormats;
    map['capabilities'] = _capabilities;
    map['useStandardizedQueries'] = _useStandardizedQueries;
    map['standardMaxRecordCount'] = _standardMaxRecordCount;
    map['tileMaxRecordCount'] = _tileMaxRecordCount;
    map['maxRecordCountFactor'] = _maxRecordCountFactor;
    return map;
  }

}

/// name : "mougis.sde.Sarawak_COVID19"
/// description : ""
/// prototype : {"attributes":{"accumulated_recovered":null,"date1":null,"date":null,"division_positive":null,"number_deaths":null,"accumulated_deaths":null,"division_death":null,"remarks":null,"point_x":null,"point_y":null,"accumulated_positive_cases":null,"daily_positive_cases":null,"daily_puis":null,"accumulated_puis":null}}
/// drawingTool : "esriFeatureEditToolPoint"

Templates templatesFromJson(String str) => Templates.fromJson(json.decode(str));
String templatesToJson(Templates data) => json.encode(data.toJson());
class Templates {
  Templates({
      String? name, 
      String? description, 
      Prototype? prototype, 
      String? drawingTool,}){
    _name = name;
    _description = description;
    _prototype = prototype;
    _drawingTool = drawingTool;
}

  Templates.fromJson(dynamic json) {
    _name = json['name'];
    _description = json['description'];
    _prototype = json['prototype'] != null ? Prototype.fromJson(json['prototype']) : null;
    _drawingTool = json['drawingTool'];
  }
  String? _name;
  String? _description;
  Prototype? _prototype;
  String? _drawingTool;
Templates copyWith({  String? name,
  String? description,
  Prototype? prototype,
  String? drawingTool,
}) => Templates(  name: name ?? _name,
  description: description ?? _description,
  prototype: prototype ?? _prototype,
  drawingTool: drawingTool ?? _drawingTool,
);
  String? get name => _name;
  String? get description => _description;
  Prototype? get prototype => _prototype;
  String? get drawingTool => _drawingTool;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['description'] = _description;
    if (_prototype != null) {
      map['prototype'] = _prototype?.toJson();
    }
    map['drawingTool'] = _drawingTool;
    return map;
  }

}

/// attributes : {"accumulated_recovered":null,"date1":null,"date":null,"division_positive":null,"number_deaths":null,"accumulated_deaths":null,"division_death":null,"remarks":null,"point_x":null,"point_y":null,"accumulated_positive_cases":null,"daily_positive_cases":null,"daily_puis":null,"accumulated_puis":null}

Prototype prototypeFromJson(String str) => Prototype.fromJson(json.decode(str));
String prototypeToJson(Prototype data) => json.encode(data.toJson());
class Prototype {
  Prototype({
      Attributes? attributes,}){
    _attributes = attributes;
}

  Prototype.fromJson(dynamic json) {
    _attributes = json['attributes'] != null ? Attributes.fromJson(json['attributes']) : null;
  }
  Attributes? _attributes;
Prototype copyWith({  Attributes? attributes,
}) => Prototype(  attributes: attributes ?? _attributes,
);
  Attributes? get attributes => _attributes;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_attributes != null) {
      map['attributes'] = _attributes?.toJson();
    }
    return map;
  }

}

/// accumulated_recovered : null
/// date1 : null
/// date : null
/// division_positive : null
/// number_deaths : null
/// accumulated_deaths : null
/// division_death : null
/// remarks : null
/// point_x : null
/// point_y : null
/// accumulated_positive_cases : null
/// daily_positive_cases : null
/// daily_puis : null
/// accumulated_puis : null

Attributes attributesFromJson(String str) => Attributes.fromJson(json.decode(str));
String attributesToJson(Attributes data) => json.encode(data.toJson());
class Attributes {
  Attributes({
      dynamic accumulatedRecovered, 
      dynamic date1, 
      dynamic date, 
      dynamic divisionPositive, 
      dynamic numberDeaths, 
      dynamic accumulatedDeaths, 
      dynamic divisionDeath, 
      dynamic remarks, 
      dynamic pointX, 
      dynamic pointY, 
      dynamic accumulatedPositiveCases, 
      dynamic dailyPositiveCases, 
      dynamic dailyPuis, 
      dynamic accumulatedPuis,}){
    _accumulatedRecovered = accumulatedRecovered;
    _date1 = date1;
    _date = date;
    _divisionPositive = divisionPositive;
    _numberDeaths = numberDeaths;
    _accumulatedDeaths = accumulatedDeaths;
    _divisionDeath = divisionDeath;
    _remarks = remarks;
    _pointX = pointX;
    _pointY = pointY;
    _accumulatedPositiveCases = accumulatedPositiveCases;
    _dailyPositiveCases = dailyPositiveCases;
    _dailyPuis = dailyPuis;
    _accumulatedPuis = accumulatedPuis;
}

  Attributes.fromJson(dynamic json) {
    _accumulatedRecovered = json['accumulated_recovered'];
    _date1 = json['date1'];
    _date = json['date'];
    _divisionPositive = json['division_positive'];
    _numberDeaths = json['number_deaths'];
    _accumulatedDeaths = json['accumulated_deaths'];
    _divisionDeath = json['division_death'];
    _remarks = json['remarks'];
    _pointX = json['point_x'];
    _pointY = json['point_y'];
    _accumulatedPositiveCases = json['accumulated_positive_cases'];
    _dailyPositiveCases = json['daily_positive_cases'];
    _dailyPuis = json['daily_puis'];
    _accumulatedPuis = json['accumulated_puis'];
  }
  dynamic _accumulatedRecovered;
  dynamic _date1;
  dynamic _date;
  dynamic _divisionPositive;
  dynamic _numberDeaths;
  dynamic _accumulatedDeaths;
  dynamic _divisionDeath;
  dynamic _remarks;
  dynamic _pointX;
  dynamic _pointY;
  dynamic _accumulatedPositiveCases;
  dynamic _dailyPositiveCases;
  dynamic _dailyPuis;
  dynamic _accumulatedPuis;
Attributes copyWith({  dynamic accumulatedRecovered,
  dynamic date1,
  dynamic date,
  dynamic divisionPositive,
  dynamic numberDeaths,
  dynamic accumulatedDeaths,
  dynamic divisionDeath,
  dynamic remarks,
  dynamic pointX,
  dynamic pointY,
  dynamic accumulatedPositiveCases,
  dynamic dailyPositiveCases,
  dynamic dailyPuis,
  dynamic accumulatedPuis,
}) => Attributes(  accumulatedRecovered: accumulatedRecovered ?? _accumulatedRecovered,
  date1: date1 ?? _date1,
  date: date ?? _date,
  divisionPositive: divisionPositive ?? _divisionPositive,
  numberDeaths: numberDeaths ?? _numberDeaths,
  accumulatedDeaths: accumulatedDeaths ?? _accumulatedDeaths,
  divisionDeath: divisionDeath ?? _divisionDeath,
  remarks: remarks ?? _remarks,
  pointX: pointX ?? _pointX,
  pointY: pointY ?? _pointY,
  accumulatedPositiveCases: accumulatedPositiveCases ?? _accumulatedPositiveCases,
  dailyPositiveCases: dailyPositiveCases ?? _dailyPositiveCases,
  dailyPuis: dailyPuis ?? _dailyPuis,
  accumulatedPuis: accumulatedPuis ?? _accumulatedPuis,
);
  dynamic get accumulatedRecovered => _accumulatedRecovered;
  dynamic get date1 => _date1;
  dynamic get date => _date;
  dynamic get divisionPositive => _divisionPositive;
  dynamic get numberDeaths => _numberDeaths;
  dynamic get accumulatedDeaths => _accumulatedDeaths;
  dynamic get divisionDeath => _divisionDeath;
  dynamic get remarks => _remarks;
  dynamic get pointX => _pointX;
  dynamic get pointY => _pointY;
  dynamic get accumulatedPositiveCases => _accumulatedPositiveCases;
  dynamic get dailyPositiveCases => _dailyPositiveCases;
  dynamic get dailyPuis => _dailyPuis;
  dynamic get accumulatedPuis => _accumulatedPuis;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['accumulated_recovered'] = _accumulatedRecovered;
    map['date1'] = _date1;
    map['date'] = _date;
    map['division_positive'] = _divisionPositive;
    map['number_deaths'] = _numberDeaths;
    map['accumulated_deaths'] = _accumulatedDeaths;
    map['division_death'] = _divisionDeath;
    map['remarks'] = _remarks;
    map['point_x'] = _pointX;
    map['point_y'] = _pointY;
    map['accumulated_positive_cases'] = _accumulatedPositiveCases;
    map['daily_positive_cases'] = _dailyPositiveCases;
    map['daily_puis'] = _dailyPuis;
    map['accumulated_puis'] = _accumulatedPuis;
    return map;
  }

}

/// timeZone : "UTC"
/// respectsDaylightSaving : false

DateFieldsTimeReference dateFieldsTimeReferenceFromJson(String str) => DateFieldsTimeReference.fromJson(json.decode(str));
String dateFieldsTimeReferenceToJson(DateFieldsTimeReference data) => json.encode(data.toJson());
class DateFieldsTimeReference {
  DateFieldsTimeReference({
      String? timeZone, 
      bool? respectsDaylightSaving,}){
    _timeZone = timeZone;
    _respectsDaylightSaving = respectsDaylightSaving;
}

  DateFieldsTimeReference.fromJson(dynamic json) {
    _timeZone = json['timeZone'];
    _respectsDaylightSaving = json['respectsDaylightSaving'];
  }
  String? _timeZone;
  bool? _respectsDaylightSaving;
DateFieldsTimeReference copyWith({  String? timeZone,
  bool? respectsDaylightSaving,
}) => DateFieldsTimeReference(  timeZone: timeZone ?? _timeZone,
  respectsDaylightSaving: respectsDaylightSaving ?? _respectsDaylightSaving,
);
  String? get timeZone => _timeZone;
  bool? get respectsDaylightSaving => _respectsDaylightSaving;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['timeZone'] = _timeZone;
    map['respectsDaylightSaving'] = _respectsDaylightSaving;
    return map;
  }

}

/// name : "r56_sde_rowid_uk"
/// fields : "objectid"
/// isAscending : true
/// isUnique : true
/// description : ""

Indexes indexesFromJson(String str) => Indexes.fromJson(json.decode(str));
String indexesToJson(Indexes data) => json.encode(data.toJson());
class Indexes {
  Indexes({
      String? name, 
      String? fields, 
      bool? isAscending, 
      bool? isUnique, 
      String? description,}){
    _name = name;
    _fields = fields;
    _isAscending = isAscending;
    _isUnique = isUnique;
    _description = description;
}

  Indexes.fromJson(dynamic json) {
    _name = json['name'];
    _fields = json['fields'];
    _isAscending = json['isAscending'];
    _isUnique = json['isUnique'];
    _description = json['description'];
  }
  String? _name;
  String? _fields;
  bool? _isAscending;
  bool? _isUnique;
  String? _description;
Indexes copyWith({  String? name,
  String? fields,
  bool? isAscending,
  bool? isUnique,
  String? description,
}) => Indexes(  name: name ?? _name,
  fields: fields ?? _fields,
  isAscending: isAscending ?? _isAscending,
  isUnique: isUnique ?? _isUnique,
  description: description ?? _description,
);
  String? get name => _name;
  String? get fields => _fields;
  bool? get isAscending => _isAscending;
  bool? get isUnique => _isUnique;
  String? get description => _description;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['fields'] = _fields;
    map['isAscending'] = _isAscending;
    map['isUnique'] = _isUnique;
    map['description'] = _description;
    return map;
  }

}

/// name : "shape"
/// type : "esriFieldTypeGeometry"
/// alias : "shape"
/// domain : null
/// editable : true
/// nullable : true
/// defaultValue : null
/// modelName : "shape"

GeometryField geometryFieldFromJson(String str) => GeometryField.fromJson(json.decode(str));
String geometryFieldToJson(GeometryField data) => json.encode(data.toJson());
class GeometryField {
  GeometryField({
      String? name, 
      String? type, 
      String? alias, 
      dynamic domain, 
      bool? editable, 
      bool? nullable, 
      dynamic defaultValue, 
      String? modelName,}){
    _name = name;
    _type = type;
    _alias = alias;
    _domain = domain;
    _editable = editable;
    _nullable = nullable;
    _defaultValue = defaultValue;
    _modelName = modelName;
}

  GeometryField.fromJson(dynamic json) {
    _name = json['name'];
    _type = json['type'];
    _alias = json['alias'];
    _domain = json['domain'];
    _editable = json['editable'];
    _nullable = json['nullable'];
    _defaultValue = json['defaultValue'];
    _modelName = json['modelName'];
  }
  String? _name;
  String? _type;
  String? _alias;
  dynamic _domain;
  bool? _editable;
  bool? _nullable;
  dynamic _defaultValue;
  String? _modelName;
GeometryField copyWith({  String? name,
  String? type,
  String? alias,
  dynamic domain,
  bool? editable,
  bool? nullable,
  dynamic defaultValue,
  String? modelName,
}) => GeometryField(  name: name ?? _name,
  type: type ?? _type,
  alias: alias ?? _alias,
  domain: domain ?? _domain,
  editable: editable ?? _editable,
  nullable: nullable ?? _nullable,
  defaultValue: defaultValue ?? _defaultValue,
  modelName: modelName ?? _modelName,
);
  String? get name => _name;
  String? get type => _type;
  String? get alias => _alias;
  dynamic get domain => _domain;
  bool? get editable => _editable;
  bool? get nullable => _nullable;
  dynamic get defaultValue => _defaultValue;
  String? get modelName => _modelName;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['type'] = _type;
    map['alias'] = _alias;
    map['domain'] = _domain;
    map['editable'] = _editable;
    map['nullable'] = _nullable;
    map['defaultValue'] = _defaultValue;
    map['modelName'] = _modelName;
    return map;
  }

}

/// name : "objectid"
/// type : "esriFieldTypeOID"
/// alias : "objectid"
/// domain : null
/// editable : false
/// nullable : false
/// defaultValue : null
/// modelName : "objectid"

Fields fieldsFromJson(String str) => Fields.fromJson(json.decode(str));
String fieldsToJson(Fields data) => json.encode(data.toJson());
class Fields {
  Fields({
      String? name, 
      String? type, 
      String? alias, 
      dynamic domain, 
      bool? editable, 
      bool? nullable, 
      dynamic defaultValue, 
      String? modelName,}){
    _name = name;
    _type = type;
    _alias = alias;
    _domain = domain;
    _editable = editable;
    _nullable = nullable;
    _defaultValue = defaultValue;
    _modelName = modelName;
}

  Fields.fromJson(dynamic json) {
    _name = json['name'];
    _type = json['type'];
    _alias = json['alias'];
    _domain = json['domain'];
    _editable = json['editable'];
    _nullable = json['nullable'];
    _defaultValue = json['defaultValue'];
    _modelName = json['modelName'];
  }
  String? _name;
  String? _type;
  String? _alias;
  dynamic _domain;
  bool? _editable;
  bool? _nullable;
  dynamic _defaultValue;
  String? _modelName;
Fields copyWith({  String? name,
  String? type,
  String? alias,
  dynamic domain,
  bool? editable,
  bool? nullable,
  dynamic defaultValue,
  String? modelName,
}) => Fields(  name: name ?? _name,
  type: type ?? _type,
  alias: alias ?? _alias,
  domain: domain ?? _domain,
  editable: editable ?? _editable,
  nullable: nullable ?? _nullable,
  defaultValue: defaultValue ?? _defaultValue,
  modelName: modelName ?? _modelName,
);
  String? get name => _name;
  String? get type => _type;
  String? get alias => _alias;
  dynamic get domain => _domain;
  bool? get editable => _editable;
  bool? get nullable => _nullable;
  dynamic get defaultValue => _defaultValue;
  String? get modelName => _modelName;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['type'] = _type;
    map['alias'] = _alias;
    map['domain'] = _domain;
    map['editable'] = _editable;
    map['nullable'] = _nullable;
    map['defaultValue'] = _defaultValue;
    map['modelName'] = _modelName;
    return map;
  }

}

/// renderer : {"type":"simple","symbol":{"type":"esriSMS","style":"esriSMSCircle","color":[181,213,252,255],"size":4,"angle":0,"xoffset":0,"yoffset":0,"outline":{"color":[0,0,0,255],"width":0.7}}}
/// scaleSymbols : true
/// transparency : 0
/// labelingInfo : null

DrawingInfo drawingInfoFromJson(String str) => DrawingInfo.fromJson(json.decode(str));
String drawingInfoToJson(DrawingInfo data) => json.encode(data.toJson());
class DrawingInfo {
  DrawingInfo({
      Renderer? renderer, 
      bool? scaleSymbols, 
      int? transparency, 
      dynamic labelingInfo,}){
    _renderer = renderer;
    _scaleSymbols = scaleSymbols;
    _transparency = transparency;
    _labelingInfo = labelingInfo;
}

  DrawingInfo.fromJson(dynamic json) {
    _renderer = json['renderer'] != null ? Renderer.fromJson(json['renderer']) : null;
    _scaleSymbols = json['scaleSymbols'];
    _transparency = json['transparency'];
    _labelingInfo = json['labelingInfo'];
  }
  Renderer? _renderer;
  bool? _scaleSymbols;
  int? _transparency;
  dynamic _labelingInfo;
DrawingInfo copyWith({  Renderer? renderer,
  bool? scaleSymbols,
  int? transparency,
  dynamic labelingInfo,
}) => DrawingInfo(  renderer: renderer ?? _renderer,
  scaleSymbols: scaleSymbols ?? _scaleSymbols,
  transparency: transparency ?? _transparency,
  labelingInfo: labelingInfo ?? _labelingInfo,
);
  Renderer? get renderer => _renderer;
  bool? get scaleSymbols => _scaleSymbols;
  int? get transparency => _transparency;
  dynamic get labelingInfo => _labelingInfo;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_renderer != null) {
      map['renderer'] = _renderer?.toJson();
    }
    map['scaleSymbols'] = _scaleSymbols;
    map['transparency'] = _transparency;
    map['labelingInfo'] = _labelingInfo;
    return map;
  }

}

/// type : "simple"
/// symbol : {"type":"esriSMS","style":"esriSMSCircle","color":[181,213,252,255],"size":4,"angle":0,"xoffset":0,"yoffset":0,"outline":{"color":[0,0,0,255],"width":0.7}}

Renderer rendererFromJson(String str) => Renderer.fromJson(json.decode(str));
String rendererToJson(Renderer data) => json.encode(data.toJson());
class Renderer {
  Renderer({
      String? type, 
      Symbol? symbol,}){
    _type = type;
    _symbol = symbol;
}

  Renderer.fromJson(dynamic json) {
    _type = json['type'];
    _symbol = json['symbol'] != null ? Symbol.fromJson(json['symbol']) : null;
  }
  String? _type;
  Symbol? _symbol;
Renderer copyWith({  String? type,
  Symbol? symbol,
}) => Renderer(  type: type ?? _type,
  symbol: symbol ?? _symbol,
);
  String? get type => _type;
  Symbol? get symbol => _symbol;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['type'] = _type;
    if (_symbol != null) {
      map['symbol'] = _symbol?.toJson();
    }
    return map;
  }

}

/// type : "esriSMS"
/// style : "esriSMSCircle"
/// color : [181,213,252,255]
/// size : 4
/// angle : 0
/// xoffset : 0
/// yoffset : 0
/// outline : {"color":[0,0,0,255],"width":0.7}

Symbol symbolFromJson(String str) => Symbol.fromJson(json.decode(str));
String symbolToJson(Symbol data) => json.encode(data.toJson());
class Symbol {
  Symbol({
      String? type, 
      String? style, 
      List<int>? color, 
      int? size, 
      int? angle, 
      int? xoffset, 
      int? yoffset, 
      Outline? outline,}){
    _type = type;
    _style = style;
    _color = color;
    _size = size;
    _angle = angle;
    _xoffset = xoffset;
    _yoffset = yoffset;
    _outline = outline;
}

  Symbol.fromJson(dynamic json) {
    _type = json['type'];
    _style = json['style'];
    _color = json['color'] != null ? json['color'].cast<int>() : [];
    _size = json['size'];
    _angle = json['angle'];
    _xoffset = json['xoffset'];
    _yoffset = json['yoffset'];
    _outline = json['outline'] != null ? Outline.fromJson(json['outline']) : null;
  }
  String? _type;
  String? _style;
  List<int>? _color;
  int? _size;
  int? _angle;
  int? _xoffset;
  int? _yoffset;
  Outline? _outline;
Symbol copyWith({  String? type,
  String? style,
  List<int>? color,
  int? size,
  int? angle,
  int? xoffset,
  int? yoffset,
  Outline? outline,
}) => Symbol(  type: type ?? _type,
  style: style ?? _style,
  color: color ?? _color,
  size: size ?? _size,
  angle: angle ?? _angle,
  xoffset: xoffset ?? _xoffset,
  yoffset: yoffset ?? _yoffset,
  outline: outline ?? _outline,
);
  String? get type => _type;
  String? get style => _style;
  List<int>? get color => _color;
  int? get size => _size;
  int? get angle => _angle;
  int? get xoffset => _xoffset;
  int? get yoffset => _yoffset;
  Outline? get outline => _outline;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['type'] = _type;
    map['style'] = _style;
    map['color'] = _color;
    map['size'] = _size;
    map['angle'] = _angle;
    map['xoffset'] = _xoffset;
    map['yoffset'] = _yoffset;
    if (_outline != null) {
      map['outline'] = _outline?.toJson();
    }
    return map;
  }

}

/// color : [0,0,0,255]
/// width : 0.7

Outline outlineFromJson(String str) => Outline.fromJson(json.decode(str));
String outlineToJson(Outline data) => json.encode(data.toJson());
class Outline {
  Outline({
      List<int>? color, 
      double? width,}){
    _color = color;
    _width = width;
}

  Outline.fromJson(dynamic json) {
    _color = json['color'] != null ? json['color'].cast<int>() : [];
    _width = json['width'];
  }
  List<int>? _color;
  double? _width;
Outline copyWith({  List<int>? color,
  double? width,
}) => Outline(  color: color ?? _color,
  width: width ?? _width,
);
  List<int>? get color => _color;
  double? get width => _width;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['color'] = _color;
    map['width'] = _width;
    return map;
  }

}

/// wkid : 4326
/// latestWkid : 4326
/// xyTolerance : 8.983152841195215E-9
/// zTolerance : 0.001
/// mTolerance : 0.001
/// falseX : -400
/// falseY : -400
/// xyUnits : 9.999999999999999E8
/// falseZ : -100000
/// zUnits : 10000
/// falseM : -100000
/// mUnits : 10000

SourceSpatialReference sourceSpatialReferenceFromJson(String str) => SourceSpatialReference.fromJson(json.decode(str));
String sourceSpatialReferenceToJson(SourceSpatialReference data) => json.encode(data.toJson());
class SourceSpatialReference {
  SourceSpatialReference({
      int? wkid, 
      int? latestWkid, 
      double? xyTolerance, 
      double? zTolerance, 
      double? mTolerance, 
      int? falseX, 
      int? falseY, 
      double? xyUnits, 
      int? falseZ, 
      int? zUnits, 
      int? falseM, 
      int? mUnits,}){
    _wkid = wkid;
    _latestWkid = latestWkid;
    _xyTolerance = xyTolerance;
    _zTolerance = zTolerance;
    _mTolerance = mTolerance;
    _falseX = falseX;
    _falseY = falseY;
    _xyUnits = xyUnits;
    _falseZ = falseZ;
    _zUnits = zUnits;
    _falseM = falseM;
    _mUnits = mUnits;
}

  SourceSpatialReference.fromJson(dynamic json) {
    _wkid = json['wkid'];
    _latestWkid = json['latestWkid'];
    _xyTolerance = json['xyTolerance'];
    _zTolerance = json['zTolerance'];
    _mTolerance = json['mTolerance'];
    _falseX = json['falseX'];
    _falseY = json['falseY'];
    _xyUnits = json['xyUnits'];
    _falseZ = json['falseZ'];
    _zUnits = json['zUnits'];
    _falseM = json['falseM'];
    _mUnits = json['mUnits'];
  }
  int? _wkid;
  int? _latestWkid;
  double? _xyTolerance;
  double? _zTolerance;
  double? _mTolerance;
  int? _falseX;
  int? _falseY;
  double? _xyUnits;
  int? _falseZ;
  int? _zUnits;
  int? _falseM;
  int? _mUnits;
SourceSpatialReference copyWith({  int? wkid,
  int? latestWkid,
  double? xyTolerance,
  double? zTolerance,
  double? mTolerance,
  int? falseX,
  int? falseY,
  double? xyUnits,
  int? falseZ,
  int? zUnits,
  int? falseM,
  int? mUnits,
}) => SourceSpatialReference(  wkid: wkid ?? _wkid,
  latestWkid: latestWkid ?? _latestWkid,
  xyTolerance: xyTolerance ?? _xyTolerance,
  zTolerance: zTolerance ?? _zTolerance,
  mTolerance: mTolerance ?? _mTolerance,
  falseX: falseX ?? _falseX,
  falseY: falseY ?? _falseY,
  xyUnits: xyUnits ?? _xyUnits,
  falseZ: falseZ ?? _falseZ,
  zUnits: zUnits ?? _zUnits,
  falseM: falseM ?? _falseM,
  mUnits: mUnits ?? _mUnits,
);
  int? get wkid => _wkid;
  int? get latestWkid => _latestWkid;
  double? get xyTolerance => _xyTolerance;
  double? get zTolerance => _zTolerance;
  double? get mTolerance => _mTolerance;
  int? get falseX => _falseX;
  int? get falseY => _falseY;
  double? get xyUnits => _xyUnits;
  int? get falseZ => _falseZ;
  int? get zUnits => _zUnits;
  int? get falseM => _falseM;
  int? get mUnits => _mUnits;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['wkid'] = _wkid;
    map['latestWkid'] = _latestWkid;
    map['xyTolerance'] = _xyTolerance;
    map['zTolerance'] = _zTolerance;
    map['mTolerance'] = _mTolerance;
    map['falseX'] = _falseX;
    map['falseY'] = _falseY;
    map['xyUnits'] = _xyUnits;
    map['falseZ'] = _falseZ;
    map['zUnits'] = _zUnits;
    map['falseM'] = _falseM;
    map['mUnits'] = _mUnits;
    return map;
  }

}

/// xmin : 114.13981543400007
/// ymin : 3.0195137160000627
/// xmax : 114.13981543400007
/// ymax : 3.0195137160000627
/// spatialReference : {"wkid":4326,"latestWkid":4326,"xyTolerance":8.983152841195215E-9,"zTolerance":0.001,"mTolerance":0.001,"falseX":-400,"falseY":-400,"xyUnits":9.999999999999999E8,"falseZ":-100000,"zUnits":10000,"falseM":-100000,"mUnits":10000}

Extent extentFromJson(String str) => Extent.fromJson(json.decode(str));
String extentToJson(Extent data) => json.encode(data.toJson());
class Extent {
  Extent({
      double? xmin, 
      double? ymin, 
      double? xmax, 
      double? ymax, 
      SpatialReference? spatialReference,}){
    _xmin = xmin;
    _ymin = ymin;
    _xmax = xmax;
    _ymax = ymax;
    _spatialReference = spatialReference;
}

  Extent.fromJson(dynamic json) {
    _xmin = json['xmin'];
    _ymin = json['ymin'];
    _xmax = json['xmax'];
    _ymax = json['ymax'];
    _spatialReference = json['spatialReference'] != null ? SpatialReference.fromJson(json['spatialReference']) : null;
  }
  double? _xmin;
  double? _ymin;
  double? _xmax;
  double? _ymax;
  SpatialReference? _spatialReference;
Extent copyWith({  double? xmin,
  double? ymin,
  double? xmax,
  double? ymax,
  SpatialReference? spatialReference,
}) => Extent(  xmin: xmin ?? _xmin,
  ymin: ymin ?? _ymin,
  xmax: xmax ?? _xmax,
  ymax: ymax ?? _ymax,
  spatialReference: spatialReference ?? _spatialReference,
);
  double? get xmin => _xmin;
  double? get ymin => _ymin;
  double? get xmax => _xmax;
  double? get ymax => _ymax;
  SpatialReference? get spatialReference => _spatialReference;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['xmin'] = _xmin;
    map['ymin'] = _ymin;
    map['xmax'] = _xmax;
    map['ymax'] = _ymax;
    if (_spatialReference != null) {
      map['spatialReference'] = _spatialReference?.toJson();
    }
    return map;
  }

}

/// wkid : 4326
/// latestWkid : 4326
/// xyTolerance : 8.983152841195215E-9
/// zTolerance : 0.001
/// mTolerance : 0.001
/// falseX : -400
/// falseY : -400
/// xyUnits : 9.999999999999999E8
/// falseZ : -100000
/// zUnits : 10000
/// falseM : -100000
/// mUnits : 10000

SpatialReference spatialReferenceFromJson(String str) => SpatialReference.fromJson(json.decode(str));
String spatialReferenceToJson(SpatialReference data) => json.encode(data.toJson());
class SpatialReference {
  SpatialReference({
      int? wkid, 
      int? latestWkid, 
      double? xyTolerance, 
      double? zTolerance, 
      double? mTolerance, 
      int? falseX, 
      int? falseY, 
      double? xyUnits, 
      int? falseZ, 
      int? zUnits, 
      int? falseM, 
      int? mUnits,}){
    _wkid = wkid;
    _latestWkid = latestWkid;
    _xyTolerance = xyTolerance;
    _zTolerance = zTolerance;
    _mTolerance = mTolerance;
    _falseX = falseX;
    _falseY = falseY;
    _xyUnits = xyUnits;
    _falseZ = falseZ;
    _zUnits = zUnits;
    _falseM = falseM;
    _mUnits = mUnits;
}

  SpatialReference.fromJson(dynamic json) {
    _wkid = json['wkid'];
    _latestWkid = json['latestWkid'];
    _xyTolerance = json['xyTolerance'];
    _zTolerance = json['zTolerance'];
    _mTolerance = json['mTolerance'];
    _falseX = json['falseX'];
    _falseY = json['falseY'];
    _xyUnits = json['xyUnits'];
    _falseZ = json['falseZ'];
    _zUnits = json['zUnits'];
    _falseM = json['falseM'];
    _mUnits = json['mUnits'];
  }
  int? _wkid;
  int? _latestWkid;
  double? _xyTolerance;
  double? _zTolerance;
  double? _mTolerance;
  int? _falseX;
  int? _falseY;
  double? _xyUnits;
  int? _falseZ;
  int? _zUnits;
  int? _falseM;
  int? _mUnits;
SpatialReference copyWith({  int? wkid,
  int? latestWkid,
  double? xyTolerance,
  double? zTolerance,
  double? mTolerance,
  int? falseX,
  int? falseY,
  double? xyUnits,
  int? falseZ,
  int? zUnits,
  int? falseM,
  int? mUnits,
}) => SpatialReference(  wkid: wkid ?? _wkid,
  latestWkid: latestWkid ?? _latestWkid,
  xyTolerance: xyTolerance ?? _xyTolerance,
  zTolerance: zTolerance ?? _zTolerance,
  mTolerance: mTolerance ?? _mTolerance,
  falseX: falseX ?? _falseX,
  falseY: falseY ?? _falseY,
  xyUnits: xyUnits ?? _xyUnits,
  falseZ: falseZ ?? _falseZ,
  zUnits: zUnits ?? _zUnits,
  falseM: falseM ?? _falseM,
  mUnits: mUnits ?? _mUnits,
);
  int? get wkid => _wkid;
  int? get latestWkid => _latestWkid;
  double? get xyTolerance => _xyTolerance;
  double? get zTolerance => _zTolerance;
  double? get mTolerance => _mTolerance;
  int? get falseX => _falseX;
  int? get falseY => _falseY;
  double? get xyUnits => _xyUnits;
  int? get falseZ => _falseZ;
  int? get zUnits => _zUnits;
  int? get falseM => _falseM;
  int? get mUnits => _mUnits;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['wkid'] = _wkid;
    map['latestWkid'] = _latestWkid;
    map['xyTolerance'] = _xyTolerance;
    map['zTolerance'] = _zTolerance;
    map['mTolerance'] = _mTolerance;
    map['falseX'] = _falseX;
    map['falseY'] = _falseY;
    map['xyUnits'] = _xyUnits;
    map['falseZ'] = _falseZ;
    map['zUnits'] = _zUnits;
    map['falseM'] = _falseM;
    map['mUnits'] = _mUnits;
    return map;
  }

}

/// supportsPagination : true
/// supportsTrueCurve : true
/// supportsQueryWithDistance : true
/// supportsReturningQueryExtent : true
/// supportsStatistics : true
/// supportsHavingClause : true
/// supportsOrderBy : true
/// supportsDistinct : true
/// supportsCountDistinct : true
/// supportsQueryWithResultType : true
/// supportsReturningGeometryCentroid : false
/// supportsSqlExpression : true

AdvancedQueryCapabilities advancedQueryCapabilitiesFromJson(String str) => AdvancedQueryCapabilities.fromJson(json.decode(str));
String advancedQueryCapabilitiesToJson(AdvancedQueryCapabilities data) => json.encode(data.toJson());
class AdvancedQueryCapabilities {
  AdvancedQueryCapabilities({
      bool? supportsPagination, 
      bool? supportsTrueCurve, 
      bool? supportsQueryWithDistance, 
      bool? supportsReturningQueryExtent, 
      bool? supportsStatistics, 
      bool? supportsHavingClause, 
      bool? supportsOrderBy, 
      bool? supportsDistinct, 
      bool? supportsCountDistinct, 
      bool? supportsQueryWithResultType, 
      bool? supportsReturningGeometryCentroid, 
      bool? supportsSqlExpression,}){
    _supportsPagination = supportsPagination;
    _supportsTrueCurve = supportsTrueCurve;
    _supportsQueryWithDistance = supportsQueryWithDistance;
    _supportsReturningQueryExtent = supportsReturningQueryExtent;
    _supportsStatistics = supportsStatistics;
    _supportsHavingClause = supportsHavingClause;
    _supportsOrderBy = supportsOrderBy;
    _supportsDistinct = supportsDistinct;
    _supportsCountDistinct = supportsCountDistinct;
    _supportsQueryWithResultType = supportsQueryWithResultType;
    _supportsReturningGeometryCentroid = supportsReturningGeometryCentroid;
    _supportsSqlExpression = supportsSqlExpression;
}

  AdvancedQueryCapabilities.fromJson(dynamic json) {
    _supportsPagination = json['supportsPagination'];
    _supportsTrueCurve = json['supportsTrueCurve'];
    _supportsQueryWithDistance = json['supportsQueryWithDistance'];
    _supportsReturningQueryExtent = json['supportsReturningQueryExtent'];
    _supportsStatistics = json['supportsStatistics'];
    _supportsHavingClause = json['supportsHavingClause'];
    _supportsOrderBy = json['supportsOrderBy'];
    _supportsDistinct = json['supportsDistinct'];
    _supportsCountDistinct = json['supportsCountDistinct'];
    _supportsQueryWithResultType = json['supportsQueryWithResultType'];
    _supportsReturningGeometryCentroid = json['supportsReturningGeometryCentroid'];
    _supportsSqlExpression = json['supportsSqlExpression'];
  }
  bool? _supportsPagination;
  bool? _supportsTrueCurve;
  bool? _supportsQueryWithDistance;
  bool? _supportsReturningQueryExtent;
  bool? _supportsStatistics;
  bool? _supportsHavingClause;
  bool? _supportsOrderBy;
  bool? _supportsDistinct;
  bool? _supportsCountDistinct;
  bool? _supportsQueryWithResultType;
  bool? _supportsReturningGeometryCentroid;
  bool? _supportsSqlExpression;
AdvancedQueryCapabilities copyWith({  bool? supportsPagination,
  bool? supportsTrueCurve,
  bool? supportsQueryWithDistance,
  bool? supportsReturningQueryExtent,
  bool? supportsStatistics,
  bool? supportsHavingClause,
  bool? supportsOrderBy,
  bool? supportsDistinct,
  bool? supportsCountDistinct,
  bool? supportsQueryWithResultType,
  bool? supportsReturningGeometryCentroid,
  bool? supportsSqlExpression,
}) => AdvancedQueryCapabilities(  supportsPagination: supportsPagination ?? _supportsPagination,
  supportsTrueCurve: supportsTrueCurve ?? _supportsTrueCurve,
  supportsQueryWithDistance: supportsQueryWithDistance ?? _supportsQueryWithDistance,
  supportsReturningQueryExtent: supportsReturningQueryExtent ?? _supportsReturningQueryExtent,
  supportsStatistics: supportsStatistics ?? _supportsStatistics,
  supportsHavingClause: supportsHavingClause ?? _supportsHavingClause,
  supportsOrderBy: supportsOrderBy ?? _supportsOrderBy,
  supportsDistinct: supportsDistinct ?? _supportsDistinct,
  supportsCountDistinct: supportsCountDistinct ?? _supportsCountDistinct,
  supportsQueryWithResultType: supportsQueryWithResultType ?? _supportsQueryWithResultType,
  supportsReturningGeometryCentroid: supportsReturningGeometryCentroid ?? _supportsReturningGeometryCentroid,
  supportsSqlExpression: supportsSqlExpression ?? _supportsSqlExpression,
);
  bool? get supportsPagination => _supportsPagination;
  bool? get supportsTrueCurve => _supportsTrueCurve;
  bool? get supportsQueryWithDistance => _supportsQueryWithDistance;
  bool? get supportsReturningQueryExtent => _supportsReturningQueryExtent;
  bool? get supportsStatistics => _supportsStatistics;
  bool? get supportsHavingClause => _supportsHavingClause;
  bool? get supportsOrderBy => _supportsOrderBy;
  bool? get supportsDistinct => _supportsDistinct;
  bool? get supportsCountDistinct => _supportsCountDistinct;
  bool? get supportsQueryWithResultType => _supportsQueryWithResultType;
  bool? get supportsReturningGeometryCentroid => _supportsReturningGeometryCentroid;
  bool? get supportsSqlExpression => _supportsSqlExpression;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['supportsPagination'] = _supportsPagination;
    map['supportsTrueCurve'] = _supportsTrueCurve;
    map['supportsQueryWithDistance'] = _supportsQueryWithDistance;
    map['supportsReturningQueryExtent'] = _supportsReturningQueryExtent;
    map['supportsStatistics'] = _supportsStatistics;
    map['supportsHavingClause'] = _supportsHavingClause;
    map['supportsOrderBy'] = _supportsOrderBy;
    map['supportsDistinct'] = _supportsDistinct;
    map['supportsCountDistinct'] = _supportsCountDistinct;
    map['supportsQueryWithResultType'] = _supportsQueryWithResultType;
    map['supportsReturningGeometryCentroid'] = _supportsReturningGeometryCentroid;
    map['supportsSqlExpression'] = _supportsSqlExpression;
    return map;
  }

}

/// supportsQueryWithHistoricMoment : false
/// startArchivingMoment : -1

ArchivingInfo archivingInfoFromJson(String str) => ArchivingInfo.fromJson(json.decode(str));
String archivingInfoToJson(ArchivingInfo data) => json.encode(data.toJson());
class ArchivingInfo {
  ArchivingInfo({
      bool? supportsQueryWithHistoricMoment, 
      int? startArchivingMoment,}){
    _supportsQueryWithHistoricMoment = supportsQueryWithHistoricMoment;
    _startArchivingMoment = startArchivingMoment;
}

  ArchivingInfo.fromJson(dynamic json) {
    _supportsQueryWithHistoricMoment = json['supportsQueryWithHistoricMoment'];
    _startArchivingMoment = json['startArchivingMoment'];
  }
  bool? _supportsQueryWithHistoricMoment;
  int? _startArchivingMoment;
ArchivingInfo copyWith({  bool? supportsQueryWithHistoricMoment,
  int? startArchivingMoment,
}) => ArchivingInfo(  supportsQueryWithHistoricMoment: supportsQueryWithHistoricMoment ?? _supportsQueryWithHistoricMoment,
  startArchivingMoment: startArchivingMoment ?? _startArchivingMoment,
);
  bool? get supportsQueryWithHistoricMoment => _supportsQueryWithHistoricMoment;
  int? get startArchivingMoment => _startArchivingMoment;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['supportsQueryWithHistoricMoment'] = _supportsQueryWithHistoricMoment;
    map['startArchivingMoment'] = _startArchivingMoment;
    return map;
  }

}