/*class AppUrl {

  //this is our bse url
  static const String baseUrl ='https://gislink.sarawak.gov.my/server/rest/services/covid19/mougis_sde_Sarawak_COVID19/FeatureServer/0?f=pjson';

  // fetch sarawak covid
static const String sarawakStateApi = baseUrl +'all';
static const String divisionList = baseUrl + 'division';

}
*/