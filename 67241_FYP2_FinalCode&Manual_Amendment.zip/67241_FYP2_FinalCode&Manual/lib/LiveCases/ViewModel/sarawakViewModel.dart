
/*
import 'dart:convert';
import 'package:covid19_info/LiveCases/ViewModel/app_url_Sarawak.dart';
import 'package:http/http.dart' as http;

import '../Model/covidSarawak.dart';

class SarawakViewModel {


  Future<CovidSarawak> fetchSarawakRecords() async {
    var data ;
    final response = await http.get(Uri.parse(AppUrl.divisionList));
    print(response.statusCode.toString());
    print(data);
    if (response.statusCode == 200) {
      data = jsonDecode(response.body.toString());
      return data;
    } else {
      throw Exception('Error');
    }

  }

}
*/