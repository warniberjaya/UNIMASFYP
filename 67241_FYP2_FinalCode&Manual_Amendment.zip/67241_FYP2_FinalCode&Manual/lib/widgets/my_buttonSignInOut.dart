import 'package:flutter/material.dart';
import 'package:covid19_info/utils/app_colors.dart';

class My_Button extends StatefulWidget {
  final void Function()? onPressed;
  final String text;
  My_Button({
    required this.onPressed,
    required this.text,
  });

  @override
  _MyButtonState createState() => _MyButtonState();
}
class _MyButtonState extends State<My_Button> {
  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: widget.onPressed,
      height: 50,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(04),
      ),
      padding: EdgeInsets.all(0),
      child: Ink(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              AppColors.Kgradient1,
              AppColors.Kgradient2,
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(04),
        ),
        child: Container(
          height: 50,
          alignment: Alignment.center,
          child: Text(
            widget.text,
            style: TextStyle(
              color: AppColors.KwhiteColor,
            ),
          ),
        ),
      ),
    );
  }
}