import 'package:flutter/material.dart';

class Location {
  final String name;
  final String image;
  final double location;
  Location({required this.image, required this.name, required this.location});
}