class AppUrl {

  //this is our bse url
  static const String baseUrl ='https://gislink.sarawak.gov.my/server/rest/services/Hosted/Division_Statistics/FeatureServer/info/iteminfo';

  // fetch sarawak covid
  static const String sarawakStateApi = baseUrl +'all';
  static const String divisionList = baseUrl + 'division';

}