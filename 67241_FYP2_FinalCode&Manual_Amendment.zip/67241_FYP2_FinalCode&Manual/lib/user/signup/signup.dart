import 'package:covid19_info/user/signup/sign_up.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:covid19_info/provider/user_provider.dart';
import 'package:covid19_info/screens/homepage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

import '../../route/routing_page.dart';

class SignIn extends StatefulWidget {
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  late UserProvider userProvider;
   _googleSignUp() async {
    try {
      final GoogleSignIn _googleSignIn = GoogleSignIn(
        scopes: ['email'],
      );
      final FirebaseAuth _auth = FirebaseAuth.instance;

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication? googleAuth =
      await googleUser?.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      final User? user = (await _auth.signInWithCredential(credential)).user;
      // print("signed in " + user.email);
      return user;
    }
   on FirebaseAuthException catch (e) {
      print(e.message.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    userProvider = Provider.of<UserProvider>(context);
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
              fit: BoxFit.cover, image: AssetImage('assets/image/background.png')),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 500,
              width: double.infinity,
              child: Column(

                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text('Sign in to continue',
                  style :
                  TextStyle(
                      height: 1.2, // the height between text, default is 1.0
                      letterSpacing: 1.0, // the white space between letter, default is 0.0
                      fontSize: 20, color: Colors.black
              )),
                  Text(
                    '\nSarawak COVID-19 Information',
                      textAlign: TextAlign.center,
                    style:
                    TextStyle(fontSize: 30, color: Colors.black),
                  ),
                  Column(
                    children: [
                      Text("\n\nSign in with Apple",
                        style:
                        TextStyle(fontSize: 20, color: Colors.black),),
                       IconButton( icon: FaIcon (FontAwesomeIcons.apple),
                      //  text: "Sign in with Apple",
                        onPressed: () {},
                      ),
                        Text("\n\nSign in with Google",
                          style:
                              TextStyle(fontSize: 20, color: Colors.black),),
                        IconButton( icon: FaIcon(FontAwesomeIcons.google),
                    //    text: "Sign in with Google",
                        onPressed: () async {
                          await _googleSignUp().then(
                                (value) => Navigator.of(context).pushReplacement(
                              MaterialPageRoute(
                                builder: (context) => Home(),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                  Column(
                    children: [ Align(
                        alignment: Alignment(0,0),
                      child:
                      Text('\nUse Other Email?',
                      style: TextStyle(
                        height: 1.2, // the height between text, default is 1.0
                        letterSpacing: 1.0, // the white space between letter, default is 0.0
                        color: Colors.blue[800],
                        fontSize: 20,

                          )
                      )),
                      ElevatedButton(
                      onPressed: () {
                        RoutingPage.goTonext(
                          context: context,
                          navigateTo: SignupPage(),
                        );
                      }, child: Text("Other gmail"),),
                      /*Text(
                        'By signing in you are agreeing to our',
                        style: TextStyle(
                          height: 1.2, // the height between text, default is 1.0
                          letterSpacing: 1.0, // the white space between letter, default is 0.0
                          color: Colors.grey[800],
                        ),
                      ),*/
                      /*Text(
                        'Terms and Pricacy Policy',
                        style: TextStyle(
                          height: 1.2, // the height between text, default is 1.0
                          letterSpacing: 1.0, // the white space between letter, default is 0.0
                          color: Colors.grey[800],
                        ),
                      ),*/
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}