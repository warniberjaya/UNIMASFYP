
import 'package:covid19_info/admin/adminscreens/adminscreen.dart';
import 'package:covid19_info/screens/homepage.dart';
import 'package:covid19_info/user/login/login.dart';
import 'package:covid19_info/user/login/login_auth_provider.dart';
import 'package:covid19_info/user/signup/signup.dart';
import 'package:covid19_info/provider/user_provider.dart';
import 'package:covid19_info/user/signup/signup_auth_provider.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'admin/services/auth_Services.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return
      MultiProvider(
    providers: [
      ChangeNotifierProvider(
        create: (context) => LoginAuthProvider(),
      ),
      ChangeNotifierProvider(
        create: (context) => SignupAuthProvider(),
      ),
      ChangeNotifierProvider(
        create: (context) => UserProvider(),
      ),
      ChangeNotifierProvider(
        create: (context) => SignupAuthCreateUserProvider(),
      ),

      ],
      child: MaterialApp(
        theme: ThemeData(
          primaryColor: Color(0xff746bc9),
          iconTheme: IconThemeData(color: Colors.black),
        ),
        debugShowCheckedModeBanner: false,
        home: StreamBuilder(
          stream: FirebaseAuth.instance.authStateChanges(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Home();
            } else {
              return LoginPage();
            }
          },
        ),
      ),
    );
  }
}
