
import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firestore_ui/firestore_list.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_geocoder/geocoder.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MapsPage extends StatefulWidget {
  const MapsPage({Key? key}) : super(key: key);

  @override
  _MapsPageState createState() => _MapsPageState();
}

class _MapsPageState extends State<MapsPage> {

  late Position position;
  GoogleMapController? myController;
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  // final Completer<GoogleMapController> mycontroller = Completer();
  var lat;
  var long;


  void initMarkers(specify, specifyId) async{
    var markerIdValue = specify;
    final MarkerId markerId = MarkerId(markerIdValue);
    final Marker marker = Marker(
      markerId: markerId,
      position: LatLng(specify['Coords'].latitude, specify['Coords'].longitude),
      // infoWindow: InfoWindow(title: 'Covid Cases', snippet: specify['Address'])
    );
    setState((){
      markers[markerId] = marker;
    });
  }



  CollectionReference users = FirebaseFirestore.instance.collection('location');

  getMarkerData() {
    users
        .doc()
        .collection('Address')
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        initMarkers(doc.data(), doc.id);
      });
    });
  }





/*  getMarkerData() async{
    //path
    FirebaseFirestore.instance.collection("location").get().then((docs) {
      if (docs.docs.isNotEmpty) {
        for (int i = 0; i < docs.docs.length; ++i) {
          initMarkers(docs.docs[i].data(), docs.docs[i].id);
        }
      }
    });
  }*/




  void initState() {
    getMarkerData();
    getCurrentLocation();
    super.initState();
  }

  void getCurrentLocation() async {
    LocationPermission permission;


    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.deniedForever) {
      lat=1.54262;long=110.612787;
    }
    else if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        lat=1.54262;long=110.612787;
      }
      else{

        Position res = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high); //getCurrentPosition();

        lat=res.latitude;long=res.longitude;

      }setState(() {
        //position = res;
        //lat=6.9271;long=79.8612;
      });
    }}

  @override
  Widget build(BuildContext context) {

    Set<Marker> getMarker(){
      return <Marker>[
        Marker(
            markerId: MarkerId('Covid Location'),
            position: LatLng(1.546842, 110.612900),
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
            infoWindow: InfoWindow(title: 'Covid Place')
        ) ].toSet();
    }



    return Scaffold(
        body:
        Stack(
            children:[ GoogleMap(
              markers: Set<Marker>.of(markers.values),
              mapType: MapType.hybrid,
              initialCameraPosition: CameraPosition(
                  target: LatLng(1.546842, 110.612900),
                  zoom: 14.0
              ),
              onMapCreated: (GoogleMapController controller){
                myController = controller;

              },
            ),
            ]));
  }
}


