import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class NewMap extends StatefulWidget {
  @override
  _NewMapState createState() => _NewMapState();
}

class _NewMapState extends State<NewMap> {
  late GoogleMapController _controller;

  late Position position;

  late Widget _child;

  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  late BitmapDescriptor pinLocationIcon;

  var lat;
  var long;

  @override
  void initState() {
    _child = SpinKitRipple(
      itemBuilder: (BuildContext context, int index) {
        return DecoratedBox(
          decoration: BoxDecoration(
            color: index.isEven ? Colors.grey : Color(0xffffb838),
          ),
        );
      },
    );
    getCurrentLocation();
    populateClients();
    setCustomMapPin();
    super.initState();
  }

  void getCurrentLocation() async {
    LocationPermission permission;


    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.deniedForever) {
      lat=1.54262;long=110.612787;
    }
    else if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        lat=1.54262;long=110.612787;
      }
      else{

        Position res = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high); //getCurrentPosition();

        lat=res.latitude;long=res.longitude;

      }setState(() {
        //position = res;
        //lat=6.9271;long=79.8612;
      });
    }}

  populateClients() {
    FirebaseFirestore.instance.collection("location").get().then((docs) {
      if (docs.docs.isNotEmpty) {
        for (int i = 0; i < docs.docs.length; ++i) {
          initMarker(docs.docs[i].data(), docs.docs[i].id);
        }
      }
    });
  }

  void initMarker(tomb, tombId) {
    var markerIdVal = tombId;
    final MarkerId markerId = MarkerId(markerIdVal);

    final Marker marker = Marker(
      markerId: markerId,
      position: LatLng(
          tomb['Coords'].latitude, tomb['Coords'].latitude),
      icon: pinLocationIcon,
    );
    setState(() {
      markers[markerId] = marker;
    });
  }

  void setCustomMapPin() async {
    pinLocationIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(devicePixelRatio: 2.5), 'assets/icon/pin.png');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xffffb838)),
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: _child,
    );
  }

  Widget mapWidget() {
    return Stack(
      children: <Widget>[
        GoogleMap(
            initialCameraPosition: CameraPosition(
              target: LatLng(position.latitude, position.longitude),
              zoom: 10,
            ),
            onMapCreated: (GoogleMapController controller) {
              _controller = controller;
            },
            compassEnabled: true,
            myLocationEnabled: true,
            markers: Set<Marker>.of(markers.values)),
        SizedBox(
          height: 26,
        ),
      ],
    );
  }
}