import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class CovidMap extends StatefulWidget {
  @override
  _CovidMap createState() => _CovidMap();
}

class _CovidMap extends State<CovidMap> {

  bool mapToggle = false;

  var currentLocation;

  late GoogleMapController mapController;

  Map<MarkerId , Marker> markers = <MarkerId , Marker>{};

  getMarkerData() async {
    FirebaseFirestore.instance.collection('location').get().then((myMarkers) {
      if(myMarkers.docs.isNotEmpty) {
        for(int i = 0; i < myMarkers.docs.length ; i++){
          initMarker(myMarkers.docs[i].data , myMarkers.docs[i].id);
        }
      }
    });
  }

  void initMarker(specify , specifyId) async {
    var markerIdVal = specifyId;
    final MarkerId markerId = MarkerId(markerIdVal);
    final Marker marker = Marker(
      markerId: markerId,
      position: LatLng(specify['Coordinate'].latitude , specify['Coordinate'].longitude),
      infoWindow: InfoWindow(title: 'Covid Place' , snippet: specify['Address']),
    );
    setState(() {
      markers[markerId] = marker;
    });
  }

  void initState() {
    getMarkerData();
    super.initState();
    Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high).then((currloc) {
      setState(() {
        currentLocation = currloc;
        mapToggle = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body:
       //   children: <Widget>[
    //        Container(
        //        height: MediaQuery.of(context).size.height - 80.0,
          //      width: double.infinity,
           //     child: mapToggle ?
                GoogleMap(
                  markers: Set<Marker>.of(markers.values),
               mapType: MapType.normal,
               //   initialCameraPosition: initialLocation,
                  myLocationEnabled: true,
                  initialCameraPosition: CameraPosition(target: LatLng(currentLocation.latitude, currentLocation.longitude),
                    zoom: 10.0,
                  ),
                  onMapCreated: (GoogleMapController controller) {
    controller = controller;},
                )
               /*     :
                Center(child:
                CircularProgressIndicator(),
                )*/
     //       )
     //     ],

      ),
    );
  }

  void onMapCreated(controller) {
    setState(() {
      mapController = controller;
    });
  }
}