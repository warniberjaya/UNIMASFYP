
import 'dart:async';
import 'dart:typed_data';


import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class Mapping extends StatefulWidget {
  const Mapping({Key? key}) : super(key: key);

  @override
  _MappingState createState() => _MappingState();
}

class _MappingState extends State<Mapping> {

  late Position position;
  GoogleMapController? myController;
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  // final Completer<GoogleMapController> mycontroller = Completer();
  var lat;
  var long;

  void initMarkers(specify, specifyId) async{
    var markerIdValue = specify;
    final MarkerId markerId = MarkerId(markerIdValue);
    final Marker marker = Marker(
      markerId: markerId,
      position: LatLng(specify['Coords'].latitude, specify['Coords'].longitude),
       infoWindow: InfoWindow( snippet: specify['Address'])
    );
    setState((){
      markers[markerId] = marker;
    });
  }
 /* List<Marker>? mapBitmapsToMarkers(List<Uint8List> bitmaps) {
    bitmaps.asMap().forEach((i, bmp)  async {
      final value = await FirebaseFirestore.instance
          .collection('location')
          .doc()
          .get();
      final data = value.data();
      final _latPoint = data!['geopoint'];
      final _lngPoint = data['geopoint'];
      var _marker = Marker(
        markerId: MarkerId("$i"),
        position: LatLng(_latPoint.latitude, _lngPoint.longitude),
        icon: BitmapDescriptor.fromBytes(bmp),
      );
      setState(() {
        customMarkers.add(_marker);
      });
    });
  }*/











  /*CollectionReference users = FirebaseFirestore.instance.collection('location');

  getMarkerData() {
    users
        .doc()
        .collection('location')
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        initMarkers(doc.data(), doc.id);
      });
    });
  }*/





  getMarkerData() {
     //path
    FirebaseFirestore.instance.collection("location").get().then((value) {
      if (value.docs.isNotEmpty) {
        for (int i = 0; i < value.docs.length; i++) {
          initMarkers(value.docs[i].data(),value.docs[i].id);

        }
      }
    });

   }

  void initState() {
    getMarkerData();
 //   getCurrentLocation();
    super.initState();
  }

  void getCurrentLocation() async {
    LocationPermission permission;


    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.deniedForever) {
      lat=1.54262;long=110.612787;
    }
    else if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        lat=1.54262;long=110.612787;
      }
      else{

        Position res = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high); //getCurrentPosition();

        lat=res.latitude;long=res.longitude;

      }setState(() {
        //position = res;
        //lat=6.9271;long=79.8612;
      });
    }}

  @override
  Widget build(BuildContext context) {

    Set<Marker> getMarker(){
      return <Marker>[
        Marker(
            markerId: MarkerId('Covid Location'),
            position: LatLng(1.546842, 110.612900),
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
            infoWindow: InfoWindow(title: 'Covid Place')
        ) ].toSet();
    }



    return Scaffold(
        body:
        Stack(
            children:[ GoogleMap(
              markers: Set<Marker>.of(markers.values),
              mapType: MapType.hybrid,
              initialCameraPosition: CameraPosition(
                  target: LatLng(1.546842, 110.612900),
                  zoom: 14.0
              ),
              onMapCreated: (GoogleMapController controller){
                myController = controller;

              },
            ),
            ]));
  }
}


