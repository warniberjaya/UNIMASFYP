
//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import '../screens/constant.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../screens/homepage.dart';
//need to settle this part first
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';



class ScreenSarawakMap extends StatefulWidget{
  @override
  _ScreenSarawakMapState createState() => _ScreenSarawakMapState();

}

class _ScreenSarawakMapState extends State<ScreenSarawakMap> {

  late GoogleMapController myController;
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
   Position? position;
    String? addressLocation;
  String? country;
  String? postalCode;
    String? City;

  //marker for maps
    void getMarkers(double lat, double long){
      MarkerId markerId = MarkerId(lat.toString() + long.toString());
      Marker _marker = Marker(
        markerId: markerId,
        position: LatLng(lat,long),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueCyan),
        infoWindow: InfoWindow(snippet: 'addressLocation'));
  setState(() {
    markers[markerId] = _marker;
  });
    }


  //get current position
    void getCurrentLocation() async{

      Position currentPosition = await GeolocatorPlatform.instance.getCurrentPosition();
      setState(() {
        position = currentPosition;

      });
    }
//call
    @override
    void initState(){
      super.initState();
      getCurrentLocation();
      position = position;
    }

  @override
    Widget build(BuildContext context){
      return Scaffold(
        body:Column(
          children: [
            SizedBox(
              height: 600.0,
              child: GoogleMap (
                onTap: (tapped) async{

                  //List<> coordinated = new await palcemarkFromCoordinates(tapped.latitude, tapped.longitude);
                  List<Placemark> addlocation = await placemarkFromCoordinates( tapped.latitude, tapped.longitude);
                //  var firstAddress = getCurrentLocation();
               /*   print("City"+addlocation[0].administrativeArea!);
                  print("Address"+addlocation[0].locality!);
                  print("Division"+addlocation[0].subLocality!);
                  print("Postal Code"+addlocation[0].postalCode!);
                  print("Street"+addlocation[0].street!);
                  */
                  getMarkers(tapped.latitude, tapped.longitude);
                //  CollectionReference Location = FirebaseFirestore.instance.collection('location');

                 await FirebaseFirestore.instance.collection('Location')
                    .add({
                    'latitude' : tapped.latitude,
                    'longitude' : tapped.longitude,
                    'Address' : tapped,
                      'City'  : City,
                    'Country' : country,
                    'PostalCode' : postalCode,
                  }).then((value ) => print ("Location Added"))
                        .catchError((error) => print("Failed to add Location: $error"));


                  setState(() {
                    City = addlocation[0].administrativeArea!;
                    country = addlocation[0].locality!;
                    postalCode = addlocation[0].postalCode!;
                    addressLocation = addlocation[0].street!;
                  });

                },
                mapType: MapType.hybrid,
                compassEnabled: true,
                trafficEnabled: true,
                initialCameraPosition:CameraPosition(
                  target:LatLng(1.546842, 110.612900),
                  zoom: 15.0
                  ),
                  // Cameraposition
                onMapCreated:(GoogleMapController controller) {
                  setState(() {
                    myController = controller;
                  });
                },
                markers: Set<Marker>.of(
                  markers.values
              ),

              ),

            ),
            Text('Address : $addressLocation'),
            Text('City: $City'),
            Text('PostalCode : $postalCode'),
             Text('Address : $country'),
          ],
        ),

        // Google Map
      );// scaffold

    }
    @override
  void dispose(){
      super.dispose();
    }
}



