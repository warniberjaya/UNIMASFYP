import 'package:flutter/material.dart';

class AppColors {
  static const KgreyColor = Color(0xff797b7a);
  static const KblackColor = Colors.black;
  static const Kgradient1 = Color(0xff027f47);
  static const Kgradient2 = Color(0xff01a95c);
  static const KwhiteColor = Colors.white;
}